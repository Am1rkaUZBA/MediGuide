/* MediGuide service worker: cache-first so the web version also works offline. Bump CACHE on every release. */
const CACHE = 'mediguide-2.0.0';
const FILES = ['./', 'index.html', 'manifest.webmanifest', 'css/app.css', 'icons/icon.svg',
  'js/data/terms-med.js', 'js/data/drugs-1.js', 'js/data/drugs-2.js', 'js/data/diseases-1.js', 'js/data/diseases-2.js',
  'js/data/symptoms.js', 'js/data/interactions.js', 'js/data/emergency.js', 'js/data/sources.js',
  'js/search.js', 'js/db.js', 'js/store.js', 'js/i18n.js', 'js/ui.js', 'js/reminders.js', 'js/views-ref.js', 'js/views-tools.js', 'js/app.js'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET' || new URL(e.request.url).origin !== location.origin) return;
  e.respondWith(caches.match(e.request).then(hit => hit || fetch(e.request)));
});
