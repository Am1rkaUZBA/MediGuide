/* MediGuide source registry.
 * Links point to the organisation's main public reference pages (stable URLs).
 * Entries say *where to verify*, they are NOT line-by-line citations. See README "Medical content status".
 */
(function (g) {
  'use strict';
  const SRC = {
    who:           { org: 'WHO', title: 'WHO fact sheets', url: 'https://www.who.int/news-room/fact-sheets' },
    who_eml:       { org: 'WHO', title: 'WHO Model List of Essential Medicines', url: 'https://www.who.int/groups/expert-committee-on-selection-and-use-of-essential-medicines/essential-medicines-lists' },
    who_atc:       { org: 'WHO', title: 'WHO Collaborating Centre for Drug Statistics (ATC/DDD)', url: 'https://atcddd.fhi.no/atc_ddd_index/' },
    mlp:           { org: 'MedlinePlus (U.S. NLM)', title: 'MedlinePlus health topics', url: 'https://medlineplus.gov/healthtopics.html' },
    mlp_drugs:     { org: 'MedlinePlus (U.S. NLM)', title: 'MedlinePlus drugs, herbs and supplements', url: 'https://medlineplus.gov/druginformation.html' },
    dailymed:      { org: 'DailyMed (U.S. NLM)', title: 'DailyMed — current FDA drug labels', url: 'https://dailymed.nlm.nih.gov/dailymed/' },
    fda_labels:    { org: 'U.S. FDA', title: 'FDA drug safety communications and labels', url: 'https://www.fda.gov/drugs/drug-safety-and-availability' },
    cdc:           { org: 'CDC', title: 'CDC health topics A–Z', url: 'https://www.cdc.gov/az/a.html' },
    ema:           { org: 'European Medicines Agency', title: 'EMA medicines', url: 'https://www.ema.europa.eu/en/medicines' }
  };

  /** Map the short keys used in disease records to a registry entry. */
  function resolve(key) {
    if (SRC[key]) return SRC[key];
    if (key.startsWith('who_')) return SRC.who;
    if (key.startsWith('mlp_')) return SRC.mlp;
    return null;
  }

  g.MG_SOURCES = { SRC, resolve };
  if (typeof module !== 'undefined') module.exports = g.MG_SOURCES;
})(typeof window !== 'undefined' ? window : globalThis);
