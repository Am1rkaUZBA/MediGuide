/* MediGuide drug-interaction rules.
 * Only widely documented interaction classes are included; the list is NOT exhaustive.
 * "No interaction found here" never means "no interaction exists". Always ask a pharmacist or doctor.
 * Rules are expanded to drug pairs at load time (see search.js / tests).
 */
(function (g) {
  'use strict';
  const NSAIDS = ['ibuprofen', 'naproxen', 'diclofenac'];
  const RAAS = ['enalapril', 'lisinopril', 'losartan'];
  const QT = ['azithromycin', 'fluconazole', 'ondansetron'];

  const EFFECTS = {
    bleeding: { sev: 'major',
      t: ['Повышенный риск кровотечений', 'Higher risk of bleeding', 'Qon ketish xavfi oshadi'] },
    inr_up: { sev: 'major',
      t: ['Может повышать эффект варфарина и риск кровотечения; нужен контроль МНО', 'May strengthen warfarin and raise bleeding risk; INR monitoring needed', "Varfarin ta'sirini kuchaytirib, qon ketish xavfini oshirishi mumkin; XNN nazorati kerak"] },
    nsaid_raas: { sev: 'moderate',
      t: ['НПВС могут ослаблять снижение давления и ухудшать функцию почек, особенно при обезвоживании и у пожилых', 'NSAIDs can weaken blood-pressure lowering and harm kidneys, especially with dehydration and in older adults', "NSYAVlar bosimni pasaytirish ta'sirini susaytirib, buyrak funksiyasini yomonlashtirishi mumkin, ayniqsa suvsizlanishda va keksalarda"] },
    nsaid_diuretic: { sev: 'moderate',
      t: ['НПВС могут ослаблять действие мочегонного и нагружать почки', 'NSAIDs can weaken the diuretic effect and strain the kidneys', "NSYAVlar siydik haydovchi ta'sirini susaytirib, buyrakka yuk berishi mumkin"] },
    raas_dual: { sev: 'major',
      t: ['Комбинация двух средств этой группы повышает риск гиперкалиемии и поражения почек', 'Combining two drugs of this kind raises the risk of high potassium and kidney injury', "Shu guruhdagi ikki dorini birga qo'llash qonda kaliy oshishi va buyrak shikastlanishi xavfini oshiradi"] },
    statin_ccb: { sev: 'moderate',
      t: ['Амлодипин повышает уровень симвастатина в крови, что увеличивает риск поражения мышц', 'Amlodipine raises simvastatin levels, increasing the risk of muscle injury', "Amlodipin simvastatin darajasini oshirib, mushaklar shikastlanishi xavfini kuchaytiradi"] },
    statin_azole: { sev: 'moderate',
      t: ['Флуконазол может повышать уровень статина в крови и риск поражения мышц', 'Fluconazole can raise statin levels and the risk of muscle injury', "Flukonazol statin darajasini va mushaklar shikastlanishi xavfini oshirishi mumkin"] },
    clopi_ppi: { sev: 'major',
      t: ['Омепразол может снижать активацию клопидогрела и его защитный эффект; врач может выбрать другой препарат для защиты желудка', 'Omeprazole may reduce activation of clopidogrel and its protective effect; a doctor may choose a different stomach-protecting drug', "Omeprazol klopidogrelning faollashuvini va himoya ta'sirini kamaytirishi mumkin; shifokor oshqozonni himoya qilish uchun boshqa dori tanlashi mumkin"] },
    hypogly: { sev: 'major',
      t: ['Возможно усиление сахароснижающего эффекта и риск гипогликемии', 'May strengthen glucose lowering and raise the risk of hypoglycemia', "Qand tushiruvchi ta'sir kuchayib, gipoglikemiya xavfi oshishi mumkin"] },
    qt: { sev: 'major',
      t: ['Оба препарата могут влиять на ритм сердца (удлинение интервала QT)', 'Both drugs can affect heart rhythm (QT prolongation)', "Ikkala dori ham yurak ritmiga ta'sir qilishi mumkin (QT intervalining uzayishi)"] },
    serotonin_qt: { sev: 'moderate',
      t: ['Возможно усиление серотонинергических эффектов и влияние на ритм сердца', 'Possible added serotonergic effects and effect on heart rhythm', "Serotonin ta'sirlarining kuchayishi va yurak ritmiga ta'sir qilishi mumkin"] },
    absorb: { sev: 'moderate',
      t: ['Железо снижает всасывание этого препарата; принимайте с интервалом по инструкции или по совету фармацевта', 'Iron reduces absorption of this drug; separate doses as the leaflet or a pharmacist advises', "Temir bu dorining so'rilishini kamaytiradi; yo'riqnoma yoki farmatsevt maslahatiga ko'ra oraliq qoldiring"] },
    absorb_ppi: { sev: 'moderate',
      t: ['Снижение кислотности может ухудшать всасывание левотироксина; врач может скорректировать контроль анализов', 'Lower stomach acid may reduce levothyroxine absorption; a doctor may adjust lab monitoring', "Kislotalik pasayishi levotiroksin so'rilishini kamaytirishi mumkin; shifokor tahlil nazoratini o'zgartirishi mumkin"] },
    gi_bleed: { sev: 'major',
      t: ['Сочетание повышает риск язв и желудочно-кишечных кровотечений', 'The combination raises the risk of ulcers and GI bleeding', "Birgalikda qo'llash yara va oshqozon-ichak qon ketishi xavfini oshiradi"] },
    glucose_up: { sev: 'moderate',
      t: ['Преднизолон может повышать уровень глюкозы в крови и ослаблять сахароснижающую терапию', 'Prednisolone can raise blood glucose and weaken glucose-lowering treatment', "Prednizolon qon glyukozasini oshirib, qand tushiruvchi davoni susaytirishi mumkin"] },
    hypok: { sev: 'moderate',
      t: ['Совместно усиливают потерю калия; возможна слабость и нарушения ритма', 'Together they increase potassium loss; weakness and rhythm problems are possible', "Birgalikda kaliy yo'qotilishini kuchaytiradi; holsizlik va ritm buzilishlari mumkin"] },
    hypercalc: { sev: 'moderate',
      t: ['Тиазиды уменьшают выведение кальция; вместе с витамином D возможно повышение кальция в крови', 'Thiazides reduce calcium excretion; with vitamin D, blood calcium may rise', "Tiazidlar kaltsiy chiqarilishini kamaytiradi; D vitamini bilan qonda kaltsiy oshishi mumkin"] },
    bb_bronch: { sev: 'moderate',
      t: ['Бета-блокаторы могут ослаблять действие сальбутамола и провоцировать бронхоспазм', 'Beta blockers can blunt salbutamol and trigger bronchospasm', "Beta-blokatorlar salbutamol ta'sirini susaytirib, bronxospazmni qo'zg'atishi mumkin"] },
    asa_ibu: { sev: 'moderate',
      t: ['Ибупрофен может снижать антиагрегантный эффект низких доз аспирина; уточните у врача порядок приёма', 'Ibuprofen may reduce the antiplatelet effect of low-dose aspirin; ask a doctor about timing', "Ibuprofen past dozali aspirinning antiagregant ta'sirini kamaytirishi mumkin; qabul tartibini shifokordan so'rang"] },
    paracetamol_inr: { sev: 'moderate',
      t: ['Регулярный приём парацетамола может повышать МНО при лечении варфарином', 'Regular paracetamol use can raise INR in people taking warfarin', "Paratsetamolni muntazam qabul qilish varfarin qabul qiluvchilarda XNN ni oshirishi mumkin"] }
  };

  /* rules: [sideA ids, sideB ids, effect key] */
  const RULES = [
    [['warfarin'], ['aspirin', 'clopidogrel', ...NSAIDS], 'bleeding'],
    [['warfarin'], ['ciprofloxacin', 'fluconazole'], 'inr_up'],
    [['warfarin'], ['paracetamol'], 'paracetamol_inr'],
    [['warfarin', 'clopidogrel', 'aspirin'], ['sertraline'], 'bleeding'],
    [NSAIDS, ['aspirin'], 'gi_bleed'],
    [['aspirin'], ['ibuprofen'], 'asa_ibu'],
    [RAAS, NSAIDS, 'nsaid_raas'],
    [['furosemide', 'hydrochlorothiazide'], NSAIDS, 'nsaid_diuretic'],
    [['enalapril', 'lisinopril'], ['losartan'], 'raas_dual'],
    [['simvastatin'], ['amlodipine'], 'statin_ccb'],
    [['simvastatin', 'atorvastatin'], ['fluconazole'], 'statin_azole'],
    [['clopidogrel'], ['omeprazole'], 'clopi_ppi'],
    [['gliclazide'], ['fluconazole', 'ciprofloxacin'], 'hypogly'],
    [QT, QT, 'qt'],
    [['sertraline'], ['ondansetron'], 'serotonin_qt'],
    [['ferrous_sulfate'], ['ciprofloxacin', 'doxycycline', 'levothyroxine'], 'absorb'],
    [['levothyroxine'], ['omeprazole', 'pantoprazole', 'famotidine'], 'absorb_ppi'],
    [['prednisolone'], [...NSAIDS, 'aspirin'], 'gi_bleed'],
    [['prednisolone'], ['gliclazide', 'metformin'], 'glucose_up'],
    [['prednisolone'], ['furosemide', 'hydrochlorothiazide'], 'hypok'],
    [['hydrochlorothiazide'], ['cholecalciferol'], 'hypercalc'],
    [['bisoprolol', 'metoprolol'], ['salbutamol'], 'bb_bronch']
  ];

  const INTERACTION_SOURCES = ['fda_labels', 'mlp_drugs'];

  /** Expand rules to a flat, de-duplicated list of {a, b, effect, sev}. */
  function expand() {
    const seen = new Set();
    const out = [];
    for (const [A, B, key] of RULES) {
      for (const a of A) for (const b of B) {
        if (a === b) continue;
        const id = [a, b].sort().join('|') + '|' + key;
        if (seen.has(id)) continue;
        seen.add(id);
        out.push({ a, b, effect: key, sev: EFFECTS[key].sev });
      }
    }
    return out;
  }

  g.MG_INTERACTIONS = { EFFECTS, RULES, expand, sources: INTERACTION_SOURCES };
  if (typeof module !== 'undefined') module.exports = g.MG_INTERACTIONS;
})(typeof window !== 'undefined' ? window : globalThis);
