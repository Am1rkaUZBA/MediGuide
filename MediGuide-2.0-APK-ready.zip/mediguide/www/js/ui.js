/* MediGuide UI helpers. SECURITY: the app never uses innerHTML. All text goes through textContent,
 * so user input (search text, journal, reminder names) cannot inject markup or scripts (XSS-safe by construction).
 */
(function (g) {
  'use strict';
  const NS = 'http://www.w3.org/2000/svg';

  // 24x24 stroke icons (single consistent style: 1.8 stroke, round caps)
  const ICONS = {
    home: 'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10',
    search: 'M11 4a7 7 0 100 14 7 7 0 000-14zM21 21l-5-5',
    grid: 'M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z',
    heart: 'M12 20s-7-4.4-9.2-9A5 5 0 0112 6a5 5 0 019.2 5C19 15.6 12 20 12 20z',
    cog: 'M12 9a3 3 0 100 6 3 3 0 000-6zM19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z',
    pill: 'M10.5 20.5a5 5 0 01-7-7l10-10a5 5 0 017 7zM8.5 8.5l7 7',
    virus: 'M12 8a4 4 0 100 8 4 4 0 000-8zM12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2',
    steth: 'M6 3v6a4 4 0 008 0V3M10 13v2a5 5 0 0010 0v-1M20 11a2 2 0 100 4 2 2 0 000-4z',
    swap: 'M7 7h13l-4-4M17 17H4l4 4',
    alert: 'M12 3L2 20h20zM12 10v5M12 18h.01',
    bell: 'M6 9a6 6 0 1112 0c0 6 3 7 3 8H3c0-1 3-2 3-8zM10 21a2 2 0 004 0',
    book: 'M4 5a2 2 0 012-2h13v16H6a2 2 0 00-2 2zM4 21V5M9 7h6',
    phone: 'M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z',
    left: 'M15 18l-6-6 6-6', right: 'M9 6l6 6-6 6',
    trash: 'M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3',
    plus: 'M12 5v14M5 12h14', x: 'M6 6l12 12M18 6L6 18', check: 'M5 12l5 5 9-10',
    clock: 'M12 3a9 9 0 100 18 9 9 0 000-18zM12 7v5l3 2',
    shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z',
    brain: 'M9 4a3 3 0 00-3 3 3 3 0 00-2 5 3 3 0 002 5 3 3 0 006 1V5a2 2 0 00-3-1zM15 4a3 3 0 013 3 3 3 0 012 5 3 3 0 01-2 5 3 3 0 01-6 1',
    drop: 'M12 3s6 6.5 6 11a6 6 0 01-12 0c0-4.5 6-11 6-11z',
    flame: 'M12 3c1 4 5 5 5 10a5 5 0 01-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-6 1-9z',
    pulse: 'M3 12h4l3-8 4 16 3-8h4',
    lungs: 'M9 4v8c0 3-1 6-4 7-2 .5-3-1-2-4 1-4 3-9 6-11zM15 4v8c0 3 1 6 4 7 2 .5 3-1 2-4-1-4-3-9-6-11z',
    link: 'M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1',
    download: 'M12 4v11M7 11l5 5 5-5M5 20h14', upload: 'M12 16V5M7 9l5-5 5 5M5 20h14',
    sun: 'M12 8a4 4 0 100 8 4 4 0 000-8zM12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M6.5 17.5L5 19',
    journal: 'M6 3h12a1 1 0 011 1v16a1 1 0 01-1 1H6zM9 3v18M12 8h4M12 12h4',
    info: 'M12 3a9 9 0 100 18 9 9 0 000-18zM12 11v5M12 8h.01',
    box: 'M3 8l9-5 9 5v8l-9 5-9-5zM3 8l9 5 9-5M12 13v8'
  };

  function icon(name, size, cls) {
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24'); svg.setAttribute('width', size || 22); svg.setAttribute('height', size || 22);
    svg.setAttribute('fill', 'none'); svg.setAttribute('stroke', 'currentColor'); svg.setAttribute('stroke-width', '1.8');
    svg.setAttribute('stroke-linecap', 'round'); svg.setAttribute('stroke-linejoin', 'round'); svg.setAttribute('aria-hidden', 'true');
    if (cls) svg.setAttribute('class', cls);
    const p = document.createElementNS(NS, 'path'); p.setAttribute('d', ICONS[name] || ICONS.info); svg.appendChild(p);
    return svg;
  }

  /** h('div.card#id', {onclick, aria-label, ...}, child, 'text', [children]) — strings become text nodes, never HTML. */
  function h(sel, attrs) {
    const m = /^([a-z0-9]+)?((?:[.#][\w-]+)*)$/i.exec(sel);
    const el = document.createElement((m && m[1]) || 'div');
    if (m && m[2]) m[2].replace(/([.#])([\w-]+)/g, (_, k, v) => { if (k === '.') el.classList.add(v); else el.id = v; });
    let start = 1;
    if (attrs && typeof attrs === 'object' && !(attrs instanceof Node) && !Array.isArray(attrs)) {
      start = 2;
      for (const k in attrs) {
        const v = attrs[k];
        if (v == null || v === false) continue;
        if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
        else if (k === 'class') v.split(' ').forEach(c => c && el.classList.add(c));
        else if (k === 'value') el.value = v;
        else if (k === 'checked' || k === 'disabled') el[k] = !!v;
        else el.setAttribute(k, v === true ? '' : String(v));
      }
    }
    for (let i = start; i < arguments.length; i++) append(el, arguments[i]);
    return el;
  }
  function append(el, c) {
    if (c == null || c === false) return;
    if (Array.isArray(c)) c.forEach(x => append(el, x));
    else if (c instanceof Node) el.appendChild(c);
    else el.appendChild(document.createTextNode(String(c)));
  }
  function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); }

  let toastEl = null, toastTimer = null;
  function toast(msg) {
    if (toastEl) toastEl.remove();
    toastEl = h('div.toast', { role: 'status' }, msg);
    document.body.appendChild(toastEl);
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { if (toastEl) toastEl.remove(); toastEl = null; }, 2200);
  }

  /** Bottom sheet dialog. Returns {close}. */
  function sheet(title, bodyNodes, onClose) {
    const prevFocus = document.activeElement;
    const ov = h('div.overlay', { role: 'dialog', 'aria-modal': 'true', 'aria-label': title });
    const box = h('div.sheet', null, h('h2', null, title), bodyNodes);
    ov.appendChild(box);
    function close() { ov.remove(); document.removeEventListener('keydown', onKey); if (prevFocus && prevFocus.focus) prevFocus.focus(); if (onClose) onClose(); }
    function onKey(e) { if (e.key === 'Escape') close(); }
    ov.addEventListener('click', e => { if (e.target === ov) close(); });
    document.addEventListener('keydown', onKey);
    document.body.appendChild(ov);
    const f = box.querySelector('button, input, textarea'); if (f) f.focus();
    return { close, el: ov };
  }

  function debounce(fn, ms) { let t; return function () { const a = arguments, c = this; clearTimeout(t); t = setTimeout(() => fn.apply(c, a), ms); }; }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }

  const api = { icon, h, clear, toast, sheet, debounce, uid, ICONS };
  g.MG_UI = api;
  if (typeof module !== 'undefined') module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
