/* Tools views: tools hub, interactions, emergency, reminders, journal, saved, settings. */
(function (g) {
  'use strict';
  const { h, icon, toast, sheet, uid, clear } = g.MG_UI;
  const DB = g.MG_DB, ST = g.MG_STORE, R = g.MG_REMINDERS;
  const t = (k, v) => g.MG_I18N.t(k, v);
  const lang = () => g.MG_I18N.getLang();
  const REF = () => g.MG_VIEWS_REF;
  const APP_VERSION = '2.0.0';

  // ---------------- TOOLS HUB ----------------
  function tools() {
    const row = (ic, cls, title, sub, path) => h('button.item', { onclick: () => g.MG.go(path) }, h('span.avatar.' + cls, null, icon(ic, 22)), h('span.grow', null, h('div.t', null, title), h('div.s', null, sub)), h('span.chev', null, icon('right', 18)));
    return h('div.view', null,
      row('swap', 'warn', t('sec_interactions'), t('ix_title'), '/interactions'),
      row('alert', 'red', t('sec_emergency'), t('em_first'), '/emergency'),
      row('bell', 'brand', t('sec_reminders'), t('rm_title'), '/reminders'),
      row('journal', 'brand', t('sec_journal'), t('jr_title'), '/journal'),
      row('steth', 'symptom', t('sec_symptoms'), t('sg_intro'), '/symptoms'),
      row('pill', 'drug', t('sec_drugs'), t('n_items', { n: DB.drugs.length }), '/drugs'),
      row('virus', 'disease', t('sec_diseases'), t('n_items', { n: DB.diseases.length }), '/diseases'),
      REF().disclaimerNote());
  }

  // ---------------- INTERACTIONS ----------------
  function interactions() {
    let chosen = ST.get('checker').filter(id => DB.drugById.has(id));
    const chosenBox = h('div.row.wrap'); const resBox = h('div.stack', { 'aria-live': 'polite' }); const sugBox = h('div.stack');
    const input = h('input.input', { type: 'search', autocomplete: 'off', placeholder: t('ix_add_ph'), 'aria-label': t('ix_add_ph') });
    function save() { ST.set('checker', chosen); }
    function paintChosen() {
      clear(chosenBox);
      chosen.forEach(id => chosenBox.appendChild(h('button.chip.drug', { 'aria-label': t('delete'), onclick: () => { chosen = chosen.filter(x => x !== id); save(); paintChosen(); paintResult(); } }, DB.labelOf({ kind: 'drug', id }, lang()), icon('x', 14))));
    }
    function paintSuggest() {
      clear(sugBox); const q = input.value.trim(); if (!q) return;
      DB.find(q, { type: 'drug', limit: 5 }).filter(r => !chosen.includes(r.item.id)).forEach(r =>
        sugBox.appendChild(h('button.item', { onclick: () => { chosen.push(r.item.id); save(); input.value = ''; clear(sugBox); paintChosen(); paintResult(); } },
          h('span.avatar.drug', null, icon('plus', 20)), h('span.grow.t', null, DB.labelOf(r.item, lang())))));
    }
    function paintResult() {
      clear(resBox);
      if (chosen.length < 2) { resBox.appendChild(h('p.muted.small', null, t('ix_need2'))); return; }
      const res = DB.checkInteractions(chosen);
      if (!res.length) { resBox.appendChild(h('section.card.ok', null, h('p', null, t('ix_none')))); return; }
      res.forEach(p => resBox.appendChild(h('section.card' + (p.effects.some(e => e.sev === 'major') ? '.red' : '.warn'), null,
        h('h3', null, DB.labelOf({ kind: 'drug', id: p.a }, lang()) + ' + ' + DB.labelOf({ kind: 'drug', id: p.b }, lang())),
        p.effects.map(e => h('p', null, h('span.chip.' + e.sev, null, t('ix_' + e.sev)), ' ', DB.effectText(e.key, lang()))))));
    }
    input.addEventListener('input', paintSuggest);
    paintChosen(); paintResult();
    return h('div.view', null,
      h('section.card.warn', null, h('p.small', null, t('ix_warn'))),
      h('p.muted.small', null, t('ix_intro')),
      h('div.field', null, input), sugBox, chosenBox, resBox,
      chosen.length ? h('button.btn.ghost', { onclick: () => { chosen = []; save(); paintChosen(); paintResult(); } }, t('ix_clear')) : null,
      REF().disclaimerNote());
  }

  // ---------------- EMERGENCY ----------------
  function emergency() {
    const E = DB.emergency; const L = { ru: 0, en: 1, uz: 2 }[lang()];
    return h('div.view', null,
      h('section.card.red', null, h('h3', null, icon('phone', 20), t('em_first')), h('p.small', null, DB.pick(E.NUMBERS.note, lang())),
        h('div.stack', null, E.NUMBERS.list.map(n => h('a.num-link', { href: 'tel:' + n.num }, icon('phone', 22), h('span', null, n.num), h('span', { style: 'font-weight:500;font-size:.8rem;opacity:.95' }, DB.pick(n.label, lang())))))),
      h('div.stack', null, E.E.map(e => h('details.card', { style: 'padding:0' },
        h('summary', { style: 'list-style:none;padding:14px 16px;display:flex;align-items:center;gap:12px;cursor:pointer;min-height:56px' },
          h('span.avatar.red', null, icon(e.icon, 22)),
          h('span.grow', null, h('div.t', { style: 'font-weight:700' }, DB.pick(e.title, lang())), h('span.chip.' + e.level, null, t('lvl_' + e.level))),
          h('span.chev', null, icon('right', 18))),
        h('div.stack', { style: 'padding:0 16px 16px' },
          h('h3', null, t('em_signs')), h('ul.bul', null, e.signs[L].map(x => h('li', null, x))),
          h('h3', null, t('em_actions')), h('ul.bul', null, e.actions[L].map(x => h('li', null, x))))))),
      h('div.disc', null, icon('info', 18), h('span', null, t('em_note'))), REF().disclaimerNote());
  }

  // ---------------- REMINDERS ----------------
  function reminders() {
    const list = h('div.stack'); const permBox = h('div.stack');
    const noteTxt = R.isNative() ? t('rm_limit_native') : t('rm_limit_web');
    const titleFn = n => t('rm_due', { n });
    async function paintPerm() {
      clear(permBox); const p = await R.permission(false);
      if (p === 'granted') return;
      if (p === 'denied') permBox.appendChild(h('section.card.warn', null, h('p.small', null, t('rm_denied'))));
      else if (p !== 'unsupported') permBox.appendChild(h('button.btn.ghost', { onclick: async () => { await R.permission(true); paintPerm(); } }, icon('bell', 18), t('rm_allow')));
    }
    function paint() {
      clear(list); const items = ST.get('reminders');
      if (!items.length) { list.appendChild(h('div.empty', null, icon('bell', 44), h('p', null, t('rm_empty')))); return; }
      items.forEach(r => list.appendChild(h('section.card', null,
        h('div.row', null, h('span.avatar.brand', null, icon('pill', 20)), h('div.grow', null, h('div.t', { style: 'font-weight:700;overflow-wrap:anywhere' }, r.name), h('div.small.muted', null, r.times.join(' · '))),
          h('button.switch', { role: 'switch', 'aria-checked': String(r.on), 'aria-label': t('rm_on'), onclick: async () => { const all = ST.get('reminders'); const x = all.find(y => y.id === r.id); x.on = !x.on; ST.set('reminders', all); if (x.on) { await R.permission(true); await R.schedule(x, titleFn); } else await R.cancel(x); paint(); } })),
        r.note ? h('p.small.muted', { style: 'overflow-wrap:anywhere' }, r.note) : null,
        h('button.btn.ghost', { onclick: async () => { await R.cancel(r); ST.set('reminders', ST.get('reminders').filter(y => y.id !== r.id)); paint(); } }, icon('trash', 18), t('delete')))));
    }
    function openAdd() {
      const name = h('input.input', { maxlength: '80', placeholder: t('rm_name'), 'aria-label': t('rm_name') });
      const note = h('input.input', { maxlength: '200', placeholder: t('rm_note'), 'aria-label': t('rm_note') });
      const times = h('div.stack'); const addTime = (v) => times.appendChild(h('input.input', { type: 'time', value: v || '08:00', 'aria-label': t('rm_time') }));
      addTime('08:00');
      const s = sheet(t('sec_reminders'), [
        h('div.field', null, h('span', null, t('rm_name')), name), h('div.field', null, h('span', null, t('rm_time')), times),
        h('button.btn.ghost', { onclick: () => times.children.length < 8 && addTime('20:00') }, t('rm_add_time')),
        h('div.field', null, h('span', null, t('rm_note')), note),
        h('div.row', null, h('button.btn.ghost.grow', { onclick: () => s.close() }, t('cancel')), h('button.btn.grow', { onclick: async () => {
          const n = name.value.trim(); if (!n) { name.focus(); return; }
          const tms = [...new Set([...times.querySelectorAll('input')].map(i => i.value).filter(v => /^\d{2}:\d{2}$/.test(v)))].sort();
          if (!tms.length) return;
          const r = { id: uid(), name: n.slice(0, 80), times: tms, note: note.value.trim().slice(0, 200), on: true };
          const all = ST.get('reminders'); all.push(r); ST.set('reminders', all);
          await R.permission(true); await R.schedule(r, titleFn); s.close(); paint(); paintPerm();
        } }, t('save')))]);
    }
    paint(); paintPerm();
    return h('div.view', null, h('section.card.warn', null, h('p.small', null, t('rm_intro'))), h('div.disc', null, icon('info', 18), h('span', null, noteTxt)),
      permBox, h('button.btn.block', { onclick: openAdd }, icon('plus', 20), t('add')), list, REF().disclaimerNote());
  }

  // ---------------- JOURNAL ----------------
  const MOODS = ['😞', '😕', '😐', '🙂', '😄'];
  function journal() {
    let mood = 0; const list = h('div.stack'); const trend = h('div');
    const text = h('textarea.input', { maxlength: '2000', placeholder: t('jr_text_ph'), 'aria-label': t('jr_text_ph') });
    const moodRow = h('div.mood', { role: 'group', 'aria-label': t('jr_mood') });
    function paintMood() { clear(moodRow); MOODS.forEach((e, i) => moodRow.appendChild(h('button', { 'aria-pressed': String(mood === i + 1), 'aria-label': t('mood' + (i + 1)), title: t('mood' + (i + 1)), onclick: () => { mood = mood === i + 1 ? 0 : i + 1; paintMood(); } }, e))); }
    const fmt = ts => new Date(ts).toLocaleString(lang() === 'uz' ? 'uz-UZ' : lang() === 'ru' ? 'ru-RU' : 'en-GB', { dateStyle: 'medium', timeStyle: 'short' });
    function paint() {
      clear(list); clear(trend); const items = ST.get('journal').slice().sort((a, b) => b.ts - a.ts);
      const withMood = items.filter(e => e.mood).slice(0, 14).reverse();
      if (withMood.length > 1) trend.appendChild(h('section.card.flat', null, h('h3', null, t('jr_trend')), h('div.spark', { role: 'img', 'aria-label': t('jr_trend') }, withMood.map(e => h('i', { style: 'height:' + (e.mood * 20) + '%', title: MOODS[e.mood - 1] }))), h('div.row', { style: 'justify-content:space-between' }, h('span.small.muted', null, '😞'), h('span.small.muted', null, '😄'))));
      if (!items.length) { list.appendChild(h('div.empty', null, icon('journal', 44), h('p', null, t('jr_empty')))); return; }
      items.forEach(e => list.appendChild(h('section.card', null, h('div.row', null, h('span', { style: 'font-size:1.5rem' }, e.mood ? MOODS[e.mood - 1] : '📝'), h('div.grow.small.muted', null, fmt(e.ts)),
        h('button.icon-btn', { 'aria-label': t('delete'), onclick: () => { ST.set('journal', ST.get('journal').filter(x => x.id !== e.id)); paint(); } }, icon('trash', 20))),
        e.text ? h('p', { style: 'white-space:pre-wrap;overflow-wrap:anywhere' }, e.text) : null)));
    }
    paintMood(); paint();
    return h('div.view', null, h('p.muted.small', null, t('jr_intro')),
      h('section.card', null, h('h3', null, t('jr_mood')), moodRow, text,
        h('button.btn.block', { onclick: () => {
          const tx = text.value.trim(); if (!tx && !mood) { toast(t('jr_save_first')); return; }
          const all = ST.get('journal'); all.push({ id: uid(), ts: Date.now(), mood, text: tx.slice(0, 2000) }); ST.set('journal', all);
          text.value = ''; mood = 0; paintMood(); paint(); toast(t('saved_ok'));
        } }, t('save'))), trend, list, REF().disclaimerNote());
  }

  // ---------------- SAVED ----------------
  function saved() {
    const favs = ST.get('favs').map(k => k.split(':')).filter(([kind, id]) => (kind === 'drug' && DB.drugById.has(id)) || (kind === 'disease' && DB.diseaseById.has(id)) || (kind === 'symptom' && DB.symptomById.has(id)));
    return h('div.view', null, h('h2', null, t('sec_favs')),
      favs.length ? h('div.stack', null, favs.map(([kind, id]) => REF().itemCard(kind, id))) : h('div.empty', null, icon('heart', 44), h('p', null, t('fav_empty'))));
  }

  // ---------------- SETTINGS ----------------
  function seg(options, current, onPick) {
    const box = h('div.seg', { role: 'radiogroup' });
    options.forEach(([val, label]) => box.appendChild(h('button', { role: 'radio', 'aria-checked': String(current === val), onclick: () => { onPick(val); } }, label)));
    return box;
  }
  function settings() {
    const s = ST.get('settings'); const d = DB.drugs.length, c = DB.diseases.length;
    const set = (k, v) => { const x = ST.get('settings'); x[k] = v; ST.set('settings', x); g.MG.applySettings(); g.MG.render(); };
    function exportSheet() {
      const json = ST.exportAll(); const ta = h('textarea.input', { readonly: true, style: 'min-height:180px;font-family:monospace;font-size:.75rem' }); ta.value = json;
      const s2 = sheet(t('st_export'), [ta, h('div.row', null,
        h('button.btn.ghost.grow', { onclick: async () => { try { await navigator.clipboard.writeText(json); toast(t('copied')); } catch (e) { ta.select(); } } }, t('copied').replace(/.*/, '⧉')),
        h('button.btn.grow', { onclick: () => { const a = h('a', { href: URL.createObjectURL(new Blob([json], { type: 'application/json' })), download: 'mediguide-backup.json' }); document.body.appendChild(a); a.click(); a.remove(); } }, icon('download', 18), t('st_export')))]);
    }
    function importSheet() {
      const ta = h('textarea.input', { style: 'min-height:140px;font-family:monospace;font-size:.75rem' });
      const file = h('input', { type: 'file', accept: 'application/json,.json', onchange: () => { const f = file.files[0]; if (!f || f.size > 2e6) return; const r = new FileReader(); r.onload = () => { ta.value = String(r.result); }; r.readAsText(f); } });
      const s2 = sheet(t('st_import'), [file, ta, h('button.btn.block', { onclick: () => { const res = ST.importAll(ta.value); toast(res.ok ? t('st_import_ok') : t('st_import_fail')); if (res.ok) { s2.close(); g.MG.render(); } } }, t('st_import'))]);
    }
    function clearSheet() {
      const s2 = sheet(t('st_clear_all'), [h('p', null, t('st_clear_confirm')), h('div.row', null, h('button.btn.ghost.grow', { onclick: () => s2.close() }, t('cancel')),
        h('button.btn.danger.grow', { onclick: async () => { for (const r of ST.get('reminders')) await R.cancel(r); ST.clearAll(); s2.close(); toast(t('st_cleared')); g.MG.boot(); } }, t('delete')))]);
    }
    return h('div.view', null,
      !ST.isPersistent() ? h('section.card.warn', null, h('p.small', null, t('st_storage_warn'))) : null,
      h('section.card', null, h('h3', null, t('st_appearance')),
        h('div.field', null, h('span', null, t('choose_lang')), seg([['ru', 'Русский'], ['en', 'English'], ['uz', "O'zbekcha"]], lang(), v => set('lang', v))),
        h('div.field', null, h('span', null, t('st_theme')), seg([['system', t('theme_system')], ['light', t('theme_light')], ['dark', t('theme_dark')]], s.theme, v => set('theme', v))),
        h('div.field', null, h('span', null, t('st_textsize')), seg([['s', t('size_s')], ['m', t('size_m')], ['l', t('size_l')]], s.textSize, v => set('textSize', v)))),
      h('section.card', null, h('h3', null, t('st_data')),
        h('button.btn.ghost.block', { onclick: exportSheet }, icon('download', 18), t('st_export')),
        h('button.btn.ghost.block', { onclick: importSheet }, icon('upload', 18), t('st_import')),
        h('button.btn.ghost.block', { onclick: () => { ST.clear('history'); toast(t('st_cleared')); } }, icon('clock', 18), t('st_clear_hist')),
        h('button.btn.danger.block', { onclick: clearSheet }, icon('trash', 18), t('st_clear_all'))),
      h('section.card', null, h('h3', null, icon('shield', 20), t('st_privacy')), h('p.small', null, t('st_privacy_text'))),
      h('section.card.warn', null, h('h3', null, icon('info', 20), t('st_content')), h('p.small', null, t('st_content_text', { d, c }))),
      h('section.card', null, h('h3', null, t('st_about')), h('dl.kv', null, h('dt', null, t('st_version')), h('dd', null, APP_VERSION), h('dt', null, t('updated', { d: '' }).replace(/:\s*$/, '')), h('dd', null, DB.DATA_UPDATED)), h('p.small.muted', null, t('disclaimer_full'))),
      sourcesAll());
  }
  function sourcesAll() {
    const S = DB.sources.SRC;
    return h('section.card.flat', null, h('h3', null, icon('book', 20), t('sec_sources')), h('p.small.muted', null, t('sources_note')),
      h('ul.stack', null, Object.values(S).map(s => h('li', null, h('a', { href: s.url, target: '_blank', rel: 'noopener noreferrer' }, s.org + ' — ' + s.title)))));
  }

  g.MG_VIEWS_TOOLS = { tools, interactions, emergency, reminders, journal, saved, settings };
})(window);
