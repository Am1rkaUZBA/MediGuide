/* MediGuide local storage. Everything stays on the device (localStorage) — nothing is sent anywhere.
 * Honest note: localStorage is NOT encrypted. Anyone with access to the unlocked device/app data can read it.
 * Every access is wrapped: storage can be blocked (private mode) → we fall back to memory for the session.
 */
(function (g) {
  'use strict';
  const PREFIX = 'mg2_';
  const mem = {};
  let persistent = true;

  function rawGet(k) {
    try { const v = localStorage.getItem(PREFIX + k); return v; } catch (e) { persistent = false; return mem[k] === undefined ? null : mem[k]; }
  }
  function rawSet(k, v) {
    try { localStorage.setItem(PREFIX + k, v); } catch (e) { persistent = false; mem[k] = v; }
  }
  function rawDel(k) {
    try { localStorage.removeItem(PREFIX + k); } catch (e) { persistent = false; }
    delete mem[k];
  }

  function get(k, fallback) {
    const v = rawGet(k);
    if (v == null) return fallback;
    try { return JSON.parse(v); } catch (e) { return fallback; }   // corrupted value → default, never crash
  }
  function set(k, v) { rawSet(k, JSON.stringify(v)); }

  const KEYS = ['settings', 'favs', 'history', 'reminders', 'journal', 'checker', 'consent'];
  const DEFAULTS = { settings: { lang: null, theme: 'system', textSize: 'm' }, favs: [], history: [], reminders: [], journal: [], checker: [], consent: false };

  const api = {
    isPersistent: () => persistent,
    get: (k) => get(k, JSON.parse(JSON.stringify(DEFAULTS[k]))),
    set,
    /** Remove ALL MediGuide data from this device. */
    clearAll() { KEYS.forEach(rawDel); },
    clear(k) { rawDel(k); },
    /** Export user data as a JSON string (user-initiated backup). */
    exportAll() { const o = { app: 'MediGuide', version: 2, exported: new Date().toISOString() }; KEYS.forEach(k => { o[k] = api.get(k); }); return JSON.stringify(o, null, 2); },
    /** Import with strict shape validation — never trust file content. */
    importAll(text) {
      let o; try { o = JSON.parse(text); } catch (e) { return { ok: false, reason: 'parse' }; }
      if (!o || o.app !== 'MediGuide' || typeof o !== 'object') return { ok: false, reason: 'format' };
      const str = (v, n) => String(v == null ? '' : v).slice(0, n);
      if (Array.isArray(o.favs)) set('favs', o.favs.filter(x => typeof x === 'string' && /^(drug|disease|symptom):[a-z0-9_]{1,40}$/.test(x)).slice(0, 500));
      if (Array.isArray(o.history)) set('history', o.history.map(x => str(x, 80)).filter(Boolean).slice(0, 30));
      if (Array.isArray(o.journal)) set('journal', o.journal.slice(0, 2000).map(e => ({ id: str(e.id, 40), ts: Number(e.ts) || Date.now(), mood: Math.max(1, Math.min(5, Number(e.mood) || 3)), text: str(e.text, 2000) })));
      if (Array.isArray(o.reminders)) set('reminders', o.reminders.slice(0, 100).map(r => ({ id: str(r.id, 40), name: str(r.name, 80), times: (Array.isArray(r.times) ? r.times : []).map(t => str(t, 5)).filter(t => /^\d{2}:\d{2}$/.test(t)).slice(0, 8), note: str(r.note, 200), on: !!r.on })));
      return { ok: true };
    }
  };
  g.MG_STORE = api;
  if (typeof module !== 'undefined') module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
