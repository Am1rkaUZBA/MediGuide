/* MediGuide DB layer: turns the compact data files into localized records and a search index.
 * Works in browser (globals) and Node (require) so tests run the same code.
 */
(function (g) {
  'use strict';
  const isNode = typeof module !== 'undefined' && typeof require === 'function';
  const LANGS = ['ru', 'en', 'uz'];
  const LI = { ru: 0, en: 1, uz: 2 };

  function load() {
    if (isNode) {
      const d = __dirname + '/data/';
      return {
        T: require(d + 'terms-med.js'),
        drugs: [...require(d + 'drugs-1.js'), ...require(d + 'drugs-2.js')],
        diseases: [...require(d + 'diseases-1.js'), ...require(d + 'diseases-2.js')],
        symptoms: require(d + 'symptoms.js'),
        interactions: require(d + 'interactions.js'),
        emergency: require(d + 'emergency.js'),
        sources: require(d + 'sources.js'),
        search: require('./search.js')
      };
    }
    return { T: g.MG_TERMS_MED, drugs: [...g.MG_DRUGS_1, ...g.MG_DRUGS_2], diseases: [...g.MG_DISEASES_1, ...g.MG_DISEASES_2],
      symptoms: g.MG_SYMPTOMS, interactions: g.MG_INTERACTIONS, emergency: g.MG_EMERGENCY, sources: g.MG_SOURCES, search: g.MG_SEARCH };
  }

  const R = load();
  const DATA_UPDATED = '2026-11-06';   // date this content bundle was assembled
  const tr = (key, lang) => { const t = R.T[key]; return t ? (t[lang] || t.en) : key; };
  const pick = (tuple, lang) => (tuple ? (tuple[LI[lang]] != null ? tuple[LI[lang]] : tuple[1]) : null);

  const drugById = new Map(R.drugs.map(d => [d.id, d]));
  const diseaseById = new Map(R.diseases.map(d => [d.id, d]));
  const symptomById = new Map(R.symptoms.map(s => [s.id, s]));
  const pairs = R.interactions.expand();
  const pairIndex = new Map();
  for (const p of pairs) {
    const k = [p.a, p.b].sort().join('|');
    if (!pairIndex.has(k)) pairIndex.set(k, []);
    pairIndex.get(k).push(p);
  }

  function drugView(d, lang) {
    return {
      kind: 'drug', id: d.id, name: pick([d.ru, d.inn, d.uz], lang), inn: d.inn, atc: d.atc, rx: d.rx,
      category: tr(d.cat, lang), forms: d.forms.map(k => tr(k, lang)), indications: d.ind.map(k => tr(k, lang)),
      contraindications: d.ci.map(k => tr(k, lang)), sideEffects: d.se.map(k => tr(k, lang)), warnings: d.w.map(k => tr(k, lang)),
      brands: d.brands, interactionIds: pairs.filter(p => p.a === d.id || p.b === d.id).map(p => (p.a === d.id ? p.b : p.a)),
      sources: ['who_atc', 'dailymed', 'mlp_drugs'].map(k => R.sources.SRC[k]), updated: DATA_UPDATED
    };
  }

  function diseaseView(d, lang) {
    const L = LI[lang];
    return {
      kind: 'disease', id: d.id, name: pick(d.title, lang), category: tr(d.cat, lang), icd: d.icd,
      summary: pick(d.desc, lang), causes: d.causes[L], symptoms: d.symptoms[L], complications: d.complications[L],
      transmission: pick(d.transmission, lang), risk: d.risk[L], diagnosis: d.diagnosis[L], treatment: pick(d.treatment, lang),
      prevention: d.prevention[L], urgent: d.urgent[L], specialists: d.spec.map(k => tr(k, lang)),
      symptomIds: d.sym, sources: d.src.map(k => R.sources.resolve(k)).filter(Boolean), updated: DATA_UPDATED
    };
  }

  function symptomView(s, lang) {
    return { kind: 'symptom', id: s.id, name: pick(s.name, lang), specialists: s.spec.map(k => tr(k, lang)), red: pick(s.red, lang),
      related: R.diseases.filter(d => d.sym.includes(s.id)).map(d => d.id) };
  }

  // ---- search index (all three languages indexed together, so any spelling finds the record) ----
  const entries = [];
  for (const d of R.drugs) {
    entries.push(R.search.makeEntry({ kind: 'drug', id: d.id }, [
      { text: d.ru, w: 1 }, { text: d.inn, w: 1 }, { text: d.uz, w: 1 },
      ...d.brands.map(b => ({ text: b, w: 0.9 })), { text: d.atc, w: 0.7 },
      ...LANGS.map(l => ({ text: tr(d.cat, l), w: 0.5 })), ...LANGS.flatMap(l => d.ind.map(k => ({ text: tr(k, l), w: 0.4 })))
    ]));
  }
  for (const d of R.diseases) {
    entries.push(R.search.makeEntry({ kind: 'disease', id: d.id }, [
      ...d.title.map(t => ({ text: t, w: 1 })), { text: d.icd, w: 0.6 },
      ...LANGS.map(l => ({ text: tr(d.cat, l), w: 0.5 })),
      ...d.sym.flatMap(s => { const sy = symptomById.get(s); return sy ? sy.name.map(t => ({ text: t, w: 0.45 })) : []; })
    ]));
  }
  for (const s of R.symptoms) {
    entries.push(R.search.makeEntry({ kind: 'symptom', id: s.id }, s.name.map(t => ({ text: t, w: 1 }))));
  }

  function find(query, opts) { return R.search.search(entries, query, opts); }

  function suggest(query, lang, n) {
    return find(query, { limit: n || 6 }).map(r => ({ kind: r.item.kind, id: r.item.id, label: labelOf(r.item, lang) }));
  }
  function labelOf(it, lang) {
    if (it.kind === 'drug') return pick([drugById.get(it.id).ru, drugById.get(it.id).inn, drugById.get(it.id).uz], lang);
    if (it.kind === 'disease') return pick(diseaseById.get(it.id).title, lang);
    return pick(symptomById.get(it.id).name, lang);
  }

  /** Check a list of drug ids; returns [{a,b,effects:[{key,sev}]}] for every pair with a documented rule. */
  function checkInteractions(ids) {
    const out = [];
    const uniq = [...new Set(ids)];
    for (let i = 0; i < uniq.length; i++) for (let j = i + 1; j < uniq.length; j++) {
      const list = pairIndex.get([uniq[i], uniq[j]].sort().join('|'));
      if (list) out.push({ a: uniq[i], b: uniq[j], effects: list.map(p => ({ key: p.effect, sev: p.sev })) });
    }
    const rank = { major: 0, moderate: 1 };
    return out.sort((x, y) => Math.min(...x.effects.map(e => rank[e.sev])) - Math.min(...y.effects.map(e => rank[e.sev])));
  }
  function effectText(key, lang) { return pick(R.interactions.EFFECTS[key].t, lang); }

  const api = {
    LANGS, DATA_UPDATED, tr, pick, drugs: R.drugs, diseases: R.diseases, symptoms: R.symptoms, emergency: R.emergency, sources: R.sources,
    drugById, diseaseById, symptomById, drugView, diseaseView, symptomView, find, suggest, labelOf, checkInteractions, effectText,
    termKeys: R.T, entries
  };
  g.MG_DB = api;
  if (isNode) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
