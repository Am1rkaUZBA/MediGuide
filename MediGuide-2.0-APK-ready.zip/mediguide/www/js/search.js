/* MediGuide search core — pure functions, no DOM (unit-tested in Node).
 * Normalisation: lower-case, ё→е, strip diacritics, Uzbek apostrophes unified, Cyrillic→Latin
 * transliteration so that "ибупрофен", "ibuprofen" and "ibuprofin" all find the same record.
 */
(function (g) {
  'use strict';

  const TRANSLIT = { а:'a',б:'b',в:'v',г:'g',д:'d',е:'e',ж:'zh',з:'z',и:'i',й:'y',к:'k',л:'l',м:'m',н:'n',о:'o',п:'p',р:'r',с:'s',т:'t',у:'u',ф:'f',х:'h',ц:'ts',ч:'ch',ш:'sh',щ:'sch',ъ:'',ы:'y',ь:'',э:'e',ю:'yu',я:'ya',ў:'o',қ:'q',ғ:'g',ҳ:'h' };

  function norm(s) {
    if (s == null) return '';
    let t = String(s).toLowerCase().replace(/ё/g, 'е');
    t = t.normalize('NFD').replace(/[̀-ͯ]/g, '');
    t = t.replace(/[ʻʼ’‘`´']/g, '');
    t = t.replace(/[^a-zа-яўқғҳ0-9+ ]+/g, ' ');
    return t.replace(/\s+/g, ' ').trim();
  }

  function translit(s) {
    let out = '';
    for (const ch of norm(s)) out += (TRANSLIT[ch] !== undefined ? TRANSLIT[ch] : ch);
    // fold look-alike sounds so ru/uz/en spellings meet in the middle
    return out.replace(/ph/g, 'f').replace(/ck/g, 'k').replace(/c(?=[eiy])/g, 's').replace(/c/g, 'k').replace(/w/g, 'v').replace(/x/g, 'ks').replace(/(.)\1+/g, '$1');
  }

  /** Damerau-Levenshtein (optimal string alignment) with early exit once distance exceeds max. */
  function distance(a, b, max) {
    if (a === b) return 0;
    const la = a.length, lb = b.length;
    if (Math.abs(la - lb) > max) return max + 1;
    const rows = [];
    for (let i = 0; i <= la; i++) { rows.push(new Array(lb + 1).fill(0)); rows[i][0] = i; }
    for (let j = 0; j <= lb; j++) rows[0][j] = j;
    for (let i = 1; i <= la; i++) {
      let rowMin = Infinity;
      for (let j = 1; j <= lb; j++) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        let v = Math.min(rows[i - 1][j] + 1, rows[i][j - 1] + 1, rows[i - 1][j - 1] + cost);
        if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) v = Math.min(v, rows[i - 2][j - 2] + 1);
        rows[i][j] = v;
        if (v < rowMin) rowMin = v;
      }
      if (rowMin > max) return max + 1;
    }
    return rows[la][lb];
  }

  /** Build a searchable entry: `keys` are weighted strings (primary names first), `words` are tokens for fuzzy match. */
  function makeEntry(item, keys) {
    const normKeys = keys.filter(Boolean).map(k => ({ n: norm(k.text), t: translit(k.text), w: k.w }));
    const words = new Set();
    for (const k of normKeys) {
      for (const w of k.n.split(' ')) if (w.length > 1) words.add(w);
      for (const w of k.t.split(' ')) if (w.length > 1) words.add(w);
    }
    return { item, keys: normKeys, words: [...words] };
  }

  function scoreEntry(entry, qn, qt, qTokens) {
    let best = 0;
    for (const k of entry.keys) {
      let s = 0;
      if (k.n === qn || k.t === qt) s = 100;
      else if (k.n.startsWith(qn) || k.t.startsWith(qt)) s = 80;
      else if (k.n.split(' ').some(w => w.startsWith(qn)) || k.t.split(' ').some(w => w.startsWith(qt))) s = 65;
      else if (k.n.includes(qn) || k.t.includes(qt)) s = 45;
      if (s) best = Math.max(best, s * k.w);
    }
    if (best) return best;
    // multi-token AND search
    if (qTokens.length > 1) {
      const hay = entry.keys.map(k => k.n + ' ' + k.t).join(' ');
      if (qTokens.every(t => hay.includes(t))) return 30;
    }
    // fuzzy: every query token must be near some word
    if (qt.length >= 4) {
      let total = 0;
      for (const tok of qTokens) {
        const tt = translit(tok);
        if (tt.length < 3 || /[0-9]/.test(tt)) return 0;
        const max = tt.length >= 8 ? 2 : 1;
        let bestD = max + 1;
        for (const w of entry.words) {
          const d = Math.min(distance(tt, translit(w), max), distance(tt, translit(w).slice(0, tt.length + 1), max));
          if (d < bestD) bestD = d;
          if (bestD === 0) break;
        }
        if (bestD > max) return 0;
        total += 20 - bestD * 6;
      }
      return total / qTokens.length;
    }
    return 0;
  }

  function search(entries, query, opts) {
    opts = opts || {};
    const qn = norm(query);
    if (!qn) return [];
    const qt = translit(query);
    const qTokens = qn.split(' ');
    const out = [];
    for (const e of entries) {
      if (opts.type && e.item.kind !== opts.type) continue;
      if (opts.filter && !opts.filter(e.item)) continue;
      const s = scoreEntry(e, qn, qt, qTokens);
      if (s > 0) out.push({ item: e.item, score: s });
    }
    out.sort((a, b) => b.score - a.score);
    return opts.limit ? out.slice(0, opts.limit) : out;
  }

  const api = { norm, translit, distance, makeEntry, search };
  g.MG_SEARCH = api;
  if (typeof module !== 'undefined') module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
