/* MediGuide app shell: hash router, top bar, bottom nav, settings, first-run disclaimer. */
(function (g) {
  'use strict';
  const { h, icon, clear, sheet, toast } = g.MG_UI;
  const I = g.MG_I18N, ST = g.MG_STORE, R = g.MG_REMINDERS;
  const t = (k, v) => I.t(k, v);
  const V = () => g.MG_VIEWS_REF, T = () => g.MG_VIEWS_TOOLS;

  const NAV = [['home', 'home', 'nav_home', '/home'], ['search', 'search', 'nav_search', '/search'], ['grid', 'tools', 'nav_tools', '/tools'], ['heart', 'saved', 'nav_saved', '/saved'], ['cog', 'settings', 'nav_settings', '/settings']];
  // route table: pattern → [view fn, title key | null, nav id]
  const ROUTES = [
    [/^\/home$/, () => V().home(), null, 'home'],
    [/^\/search$/, p => V().search(p), 'nav_search', 'search'],
    [/^\/drugs$/, () => V().drugsList(), 'sec_drugs', 'tools'],
    [/^\/diseases$/, () => V().diseasesList(), 'sec_diseases', 'tools'],
    [/^\/symptoms$/, () => V().symptomsList(), 'sec_symptoms', 'tools'],
    [/^\/drug\/([\w]+)$/, (p, m) => V().drug(p, m[1]), null, 'tools'],
    [/^\/disease\/([\w]+)$/, (p, m) => V().disease(p, m[1]), null, 'tools'],
    [/^\/symptom\/([\w]+)$/, (p, m) => V().symptom(p, m[1]), null, 'tools'],
    [/^\/tools$/, () => T().tools(), 'nav_tools', 'tools'],
    [/^\/interactions$/, () => T().interactions(), 'ix_title', 'tools'],
    [/^\/emergency$/, () => T().emergency(), 'em_title', 'tools'],
    [/^\/reminders$/, () => T().reminders(), 'rm_title', 'tools'],
    [/^\/journal$/, () => T().journal(), 'jr_title', 'tools'],
    [/^\/saved$/, () => T().saved(), 'nav_saved', 'saved'],
    [/^\/settings$/, () => T().settings(), 'nav_settings', 'settings']
  ];

  const MG = { cur: null, depth: 0 };
  let topbar, main, nav;

  function parse() {
    const raw = (location.hash || '#/home').slice(1) || '/home';
    const [path, qs] = raw.split('?');
    return { path, params: new URLSearchParams(qs || '') };
  }

  MG.go = function (path) { MG.depth++; location.hash = '#' + path; };
  MG.back = function () { if (MG.depth > 0) { MG.depth--; history.back(); } else location.hash = '#/home'; };

  MG.render = function () {
    const { path, params } = parse();
    let node = null, titleKey = null, navId = 'home', isHome = false;
    for (const [re, fn, tk, nid] of ROUTES) {
      const m = re.exec(path);
      if (m) { try { node = fn(params, m); } catch (e) { console.error(e); node = h('div.view', null, h('div.empty', null, icon('alert', 44), h('p', null, t('error_generic')))); } titleKey = tk; navId = nid; isHome = path === '/home'; break; }
    }
    if (!node) { node = V().notFound(); }
    clear(main); main.appendChild(node); main.scrollTop = 0;
    paintTop(isHome, titleKey, node);
    paintNav(navId);
    document.title = 'MediGuide';
  };

  function paintTop(isHome, titleKey, node) {
    clear(topbar);
    const inner = h('div.topbar-in');
    if (isHome) {
      inner.appendChild(h('div.brand', null, h('span.brand-mark', null, icon('pulse', 20)), 'MediGuide'));
      inner.appendChild(h('button.lang-pill', { 'aria-label': t('choose_lang'), onclick: cycleLang }, I.getLang().toUpperCase()));
    } else {
      inner.appendChild(h('button.icon-btn', { 'aria-label': t('back'), onclick: MG.back }, icon('left', 24)));
      const h1 = node.querySelector && node.querySelector('h1');
      inner.appendChild(h('div.topbar-title', null, titleKey ? t(titleKey) : (h1 ? h1.textContent : '')));
    }
    topbar.appendChild(inner);
    if (g.navigator && navigator.onLine === false) topbar.appendChild(h('div.banner', { role: 'status' }, t('offline_banner')));
  }
  function paintNav(active) {
    clear(nav);
    NAV.forEach(([ic, id, key, path]) => nav.appendChild(h('button', { 'aria-current': id === active ? 'page' : null, onclick: () => { MG.depth = 0; location.hash = '#' + path; } }, icon(ic, 24), h('span', null, t(key)))));
  }
  function cycleLang() {
    const order = ['ru', 'en', 'uz']; const next = order[(order.indexOf(I.getLang()) + 1) % 3];
    const s = ST.get('settings'); s.lang = next; ST.set('settings', s); MG.applySettings(); MG.render();
  }

  MG.applySettings = function () {
    const s = ST.get('settings');
    I.setLang(s.lang || I.detect());
    const dark = s.theme === 'dark' || (s.theme === 'system' && g.matchMedia && g.matchMedia('(prefers-color-scheme: dark)').matches);
    const root = document.documentElement;
    root.setAttribute('data-theme', dark ? 'dark' : 'light'); root.setAttribute('data-size', s.textSize || 'm'); root.lang = I.getLang();
    const meta = document.querySelector('meta[name="theme-color"]'); if (meta) meta.setAttribute('content', dark ? '#141f29' : '#ffffff');
  };

  function welcome() {
    const s = ST.get('settings');
    const box = h('div.stack');
    function paint() {
      clear(box);
      ['ru', 'en', 'uz'].forEach(l => box.appendChild(h('button.item', { onclick: () => { const x = ST.get('settings'); x.lang = l; ST.set('settings', x); MG.applySettings(); ov.close(); welcome(); } },
        h('span.avatar.brand', null, icon('check', 20)), h('span.grow.t', null, { ru: 'Русский', en: 'English', uz: "O'zbekcha" }[l]), I.getLang() === l ? h('span.chip', null, '✓') : null)));
    }
    paint();
    const ov = sheet(t('welcome_title'), [
      box,
      h('section.card.warn', null, h('p.small', null, t('disclaimer_full'))),
      h('p.small.muted', null, t('welcome_privacy')),
      h('button.btn.block', { onclick: () => { ST.set('consent', true); ov.close(); } }, t('welcome_accept'))]);
    // consent sheet must not be dismissed by tapping the backdrop or Esc without acknowledging
    ov.el.addEventListener('click', e => { if (e.target === ov.el) e.stopPropagation(); }, true);
  }

  MG.boot = function () {
    MG.applySettings(); MG.render();
    if (!ST.get('consent')) welcome();
    R.syncAll(n => t('rm_due', { n })).catch(() => {});
  };

  function init() {
    topbar = document.getElementById('topbar'); main = document.getElementById('main'); nav = document.getElementById('nav');
    g.MG = MG;
    g.addEventListener('hashchange', MG.render);
    g.addEventListener('online', MG.render); g.addEventListener('offline', MG.render);
    if (g.matchMedia) g.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', MG.applySettings);
    R.startWebWatcher(r => { const s = sheet(t('sec_reminders'), [h('p', { style: 'font-size:1.1rem;font-weight:700;overflow-wrap:anywhere' }, t('rm_due', { n: r.name })), r.note ? h('p.muted', null, r.note) : null, h('button.btn.block', { onclick: () => s.close() }, t('ok'))]);
      try { if (typeof Notification !== 'undefined' && Notification.permission === 'granted') new Notification('MediGuide', { body: t('rm_due', { n: r.name }) }); } catch (e) { /* ignore */ } });
    // Android hardware back button (Capacitor)
    try { const A = g.Capacitor && g.Capacitor.Plugins && g.Capacitor.Plugins.App; if (A && A.addListener) A.addListener('backButton', () => { const { path } = parse(); if (path === '/home') A.exitApp(); else MG.back(); }); } catch (e) { /* ignore */ }
    if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(() => {});
    MG.boot();
  }

  g.MG = MG;
  g.addEventListener('error', e => console.error('MG error:', e.message));
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})(window);
