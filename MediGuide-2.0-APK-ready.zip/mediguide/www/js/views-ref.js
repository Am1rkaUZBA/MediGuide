/* Reference views: home, search, lists, drug / disease / symptom detail. */
(function (g) {
  'use strict';
  const { h, icon, toast, debounce } = g.MG_UI;
  const DB = g.MG_DB, ST = g.MG_STORE;
  const t = (k, v) => g.MG_I18N.t(k, v);
  const lang = () => g.MG_I18N.getLang();
  const KIND_ICON = { drug: 'pill', disease: 'virus', symptom: 'steth' };

  const favKey = (kind, id) => kind + ':' + id;
  const isFav = (kind, id) => ST.get('favs').includes(favKey(kind, id));
  function toggleFav(kind, id) {
    const f = ST.get('favs'); const k = favKey(kind, id); const i = f.indexOf(k);
    if (i >= 0) f.splice(i, 1); else f.unshift(k);
    ST.set('favs', f); toast(t(i >= 0 ? 'fav_removed' : 'fav_added'));
    return i < 0;
  }

  function favButton(kind, id) {
    const btn = h('button.icon-btn', { 'aria-label': t('sec_favs'), 'aria-pressed': String(isFav(kind, id)) });
    const paint = () => { btn.textContent = ''; const on = isFav(kind, id); btn.setAttribute('aria-pressed', String(on)); const ic = icon('heart', 22); if (on) { ic.setAttribute('fill', 'currentColor'); btn.style.color = 'var(--danger)'; } else btn.style.color = ''; btn.appendChild(ic); };
    btn.addEventListener('click', e => { e.stopPropagation(); toggleFav(kind, id); paint(); });
    paint(); return btn;
  }

  function summaryOf(kind, id) {
    if (kind === 'drug') { const d = DB.drugById.get(id); return DB.tr(d.cat, lang()); }
    if (kind === 'disease') { const d = DB.diseaseById.get(id); return DB.tr(d.cat, lang()); }
    return DB.symptomView(DB.symptomById.get(id), lang()).specialists[0] || '';
  }

  function itemCard(kind, id, opts) {
    opts = opts || {};
    const sub = kind === 'drug' ? [DB.drugById.get(id).inn, summaryOf(kind, id)].filter((v, i, a) => a.indexOf(v) === i).join(' · ') : summaryOf(kind, id);
    return h('button.item', { onclick: () => { if (opts.query) addHistory(opts.query); g.MG.go('/' + kind + '/' + id); } },
      h('span.avatar.' + kind, null, icon(KIND_ICON[kind], 22)),
      h('span.grow', null, h('div.t', null, DB.labelOf({ kind, id }, lang())), h('div.s', null, sub)),
      opts.noFav ? null : favButton(kind, id),
      h('span.chev', null, icon('right', 18)));
  }

  function addHistory(q) {
    q = String(q || '').trim().slice(0, 80); if (q.length < 2) return;
    const hst = ST.get('history').filter(x => x.toLowerCase() !== q.toLowerCase()); hst.unshift(q);
    ST.set('history', hst.slice(0, 20));
  }

  function disclaimerNote() {
    return h('div.disc', { role: 'note' }, icon('shield', 18), h('span', null, t('disclaimer_short')));
  }

  // ---------------- HOME ----------------
  function home() {
    const tile = (ic, cls, title, sub, path) => h('button.tile', { onclick: () => g.MG.go(path) }, h('span.avatar.' + cls, null, icon(ic, 22)), h('div', null, h('div.t', null, title), h('div.s', null, sub)));
    return h('div.view', null,
      h('section.hero', null, h('h1', null, t('home_title')), h('p', null, t('home_sub'))),
      h('button.searchbox', { style: 'text-align:left', onclick: () => g.MG.go('/search'), 'aria-label': t('nav_search') },
        h('div.input', { style: 'display:flex;align-items:center;gap:10px;min-height:52px;border-radius:16px;color:var(--muted)' }, icon('search', 20), h('span.ph-line', null, t('search_ph')))),
      h('button.emerg-card', { onclick: () => g.MG.go('/emergency') },
        h('span.avatar.red', null, icon('alert', 22)),
        h('span.grow', null, h('div.t', null, t('home_emerg_title')), h('div.s.small.muted', null, t('home_emerg_sub'))),
        h('span.chev', null, icon('right', 18))),
      h('h2', null, t('home_quick')),
      h('div.grid2', null,
        tile('pill', 'drug', t('sec_drugs'), t('n_items', { n: DB.drugs.length }), '/drugs'),
        tile('virus', 'disease', t('sec_diseases'), t('n_items', { n: DB.diseases.length }), '/diseases'),
        tile('steth', 'symptom', t('sec_symptoms'), t('n_items', { n: DB.symptoms.length }), '/symptoms'),
        tile('swap', 'warn', t('sec_interactions'), t('ix_title'), '/interactions'),
        tile('bell', 'brand', t('sec_reminders'), t('rm_title'), '/reminders'),
        tile('journal', 'brand', t('sec_journal'), t('jr_title'), '/journal')),
      disclaimerNote());
  }

  // ---------------- SEARCH ----------------
  function search(params) {
    let filter = params.get('type') || 'all';
    const initial = params.get('q') || '';
    const input = h('input.input', { type: 'search', enterkeyhint: 'search', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', placeholder: t('search_ph'), 'aria-label': t('nav_search'), value: initial, style: 'height:52px;border-radius:16px;padding-left:46px' });
    const clearBtn = h('button.icon-btn.clear', { 'aria-label': t('close'), style: 'position:absolute;right:4px;top:4px;display:none', onclick: () => { input.value = ''; run(); input.focus(); } }, icon('x', 20));
    const box = h('div.searchbox', null, h('span.lead', null, icon('search', 20)), input, clearBtn);
    const results = h('div.stack', { 'aria-live': 'polite' });
    const chips = h('div.chips-scroll', { role: 'group' });

    function paintChips() {
      chips.textContent = '';
      [['all', 'filter_all'], ['drug', 'filter_drug'], ['disease', 'filter_disease'], ['symptom', 'filter_symptom']].forEach(([k, lbl]) =>
        chips.appendChild(h('button.fchip', { 'aria-pressed': String(filter === k), onclick: () => { filter = k; paintChips(); run(); } }, t(lbl))));
    }

    function run() {
      const q = input.value.trim();
      clearBtn.style.display = q ? 'grid' : 'none';
      results.textContent = '';
      if (!q) {
        const hist = ST.get('history');
        if (hist.length) {
          results.appendChild(h('div.row', null, h('h3.grow', null, t('recent')), h('button.chip', { onclick: () => { ST.clear('history'); run(); } }, t('clear_history'))));
          hist.forEach(x => results.appendChild(h('button.item', { onclick: () => { input.value = x; run(); } }, h('span.avatar.brand', null, icon('clock', 20)), h('span.grow.t', null, x), h('span.chev', null, icon('right', 18)))));
        } else results.appendChild(h('p.muted.small', null, t('search_hint')));
        return;
      }
      const found = DB.find(q, { type: filter === 'all' ? null : filter, limit: 40 });
      if (!found.length) {
        results.appendChild(h('div.empty', null, icon('box', 44), h('h3', null, t('no_results')), h('p.small', null, t('no_results_sub'))));
        return;
      }
      results.appendChild(h('p.muted.small', null, t('results_n', { n: found.length })));
      found.forEach(r => results.appendChild(itemCard(r.item.kind, r.item.id, { query: q })));
    }
    input.addEventListener('input', debounce(run, 120));
    input.addEventListener('keydown', e => { if (e.key === 'Enter') { addHistory(input.value); input.blur(); } });
    paintChips(); run();
    setTimeout(() => { if (!initial) input.focus(); }, 60);
    return h('div.view', null, box, chips, results);
  }

  // ---------------- LISTS ----------------
  function alphaList(kind, rows, filterCats) {
    let cat = 'all';
    const list = h('div.stack'); const chips = h('div.chips-scroll');
    function paint() {
      chips.textContent = '';
      chips.appendChild(h('button.fchip', { 'aria-pressed': String(cat === 'all'), onclick: () => { cat = 'all'; paint(); } }, t('filter_all')));
      filterCats.forEach(c => chips.appendChild(h('button.fchip', { 'aria-pressed': String(cat === c), onclick: () => { cat = c; paint(); } }, DB.tr(c, lang()))));
      list.textContent = '';
      rows.filter(r => cat === 'all' || r.cat === cat)
        .sort((a, b) => a.label.localeCompare(b.label, lang()))
        .forEach(r => list.appendChild(itemCard(kind, r.id)));
    }
    paint();
    return h('div.view', null, chips, list);
  }
  const drugsList = () => alphaList('drug', DB.drugs.map(d => ({ id: d.id, cat: d.cat, label: DB.labelOf({ kind: 'drug', id: d.id }, lang()) })), [...new Set(DB.drugs.map(d => d.cat))]);
  const diseasesList = () => alphaList('disease', DB.diseases.map(d => ({ id: d.id, cat: d.cat, label: DB.labelOf({ kind: 'disease', id: d.id }, lang()) })), [...new Set(DB.diseases.map(d => d.cat))]);
  function symptomsList() {
    return h('div.view', null, h('div.disc', null, icon('info', 18), h('span', null, t('sg_intro'))),
      h('div.stack', null, DB.symptoms.map(s => ({ id: s.id, label: DB.labelOf({ kind: 'symptom', id: s.id }, lang()) })).sort((a, b) => a.label.localeCompare(b.label, lang())).map(r => itemCard('symptom', r.id))));
  }

  // ---------------- DETAIL helpers ----------------
  const bullets = arr => h('ul.bul', null, arr.map(x => h('li', null, x)));
  const sec = (title, body, cls, ic) => h('section.card' + (cls ? '.' + cls : ''), null, h('h3', null, ic ? icon(ic, 20) : null, title), body);

  function sourcesBlock(srcs, updated) {
    return h('section.card.flat', null,
      h('h3', null, icon('book', 20), t('sec_sources')),
      h('p.small.muted', null, t('sources_note')),
      h('ul.stack', null, srcs.map(s => h('li', null, h('a', { href: s.url, target: '_blank', rel: 'noopener noreferrer' }, s.org + ' — ' + s.title)))),
      h('p.small.muted', null, t('updated', { d: updated })));
  }

  function header(kind, name, extra) {
    return h('div.row', null, h('span.avatar.' + kind, { style: 'width:52px;height:52px' }, icon(KIND_ICON[kind], 26)),
      h('div.grow', null, h('span.chip.' + kind, null, t('kind_' + kind)), h('h1', { style: 'margin-top:4px;overflow-wrap:anywhere' }, name), extra || null),
      favButton(kind, kind === 'drug' ? g.MG.cur.id : g.MG.cur.id));
  }

  // ---------------- DRUG ----------------
  function drug(params, id) {
    const raw = DB.drugById.get(id); if (!raw) return notFound();
    const d = DB.drugView(raw, lang()); g.MG.cur = { kind: 'drug', id };
    const inter = d.interactionIds.map(oid => ({ oid, effects: DB.checkInteractions([id, oid])[0].effects }));
    return h('div.view', null,
      header('drug', d.name, d.name !== d.inn ? h('p.muted', null, d.inn) : null),
      h('div.card', null, h('dl.kv', null,
        h('dt', null, t('d_inn')), h('dd', null, d.inn), h('dt', null, t('d_atc')), h('dd', null, d.atc),
        h('dt', null, t('d_category')), h('dd', null, d.category), h('dt', null, 'Rx'), h('dd', null, t('rx_' + d.rx)),
        h('dt', null, t('d_forms')), h('dd', null, d.forms.join(', ')),
        h('dt', null, t('d_brands')), h('dd', null, d.brands.join(', ')))),
      h('p.small.muted', null, t('d_brands_note')),
      sec(t('d_ind'), bullets(d.indications), null, 'check'),
      sec(t('d_ci'), bullets(d.contraindications), 'red', 'alert'),
      sec(t('d_se'), bullets(d.sideEffects), null, 'info'),
      sec(t('d_w'), bullets(d.warnings), 'warn', 'shield'),
      sec(t('d_inter'), inter.length
        ? h('div.stack', null, inter.map(x => h('div.stack', null,
            h('button.item', { onclick: () => g.MG.go('/drug/' + x.oid) }, h('span.avatar.drug', null, icon('pill', 20)), h('span.grow.t', null, DB.labelOf({ kind: 'drug', id: x.oid }, lang())), h('span.chev', null, icon('right', 18))),
            x.effects.map(e => h('p.small', null, h('span.chip.' + e.sev, null, t('ix_' + e.sev)), ' ', DB.effectText(e.key, lang()))))))
        : h('p.muted', null, t('d_inter_none')), null, 'swap'),
      h('div.disc', null, icon('info', 18), h('span', null, t('d_dose_note'))),
      sourcesBlock(d.sources, d.updated), disclaimerNote());
  }

  // ---------------- DISEASE ----------------
  function disease(params, id) {
    const raw = DB.diseaseById.get(id); if (!raw) return notFound();
    const d = DB.diseaseView(raw, lang()); g.MG.cur = { kind: 'disease', id };
    const parts = [
      header('disease', d.name, h('p.small.muted', null, d.category + ' · ' + t('x_icd') + ': ' + d.icd)),
      h('p', null, d.summary),
      d.urgent && d.urgent.length ? sec(t('x_urgent'), bullets(d.urgent), 'red', 'alert') : null,
      sec(t('x_symptoms'), bullets(d.symptoms), null, 'steth'),
      sec(t('x_causes'), bullets(d.causes)),
      d.transmission ? sec(t('x_transmission'), h('p', null, d.transmission)) : null,
      sec(t('x_risk'), bullets(d.risk)),
      sec(t('x_complications'), bullets(d.complications)),
      sec(t('x_diagnosis'), bullets(d.diagnosis)),
      sec(t('x_treatment'), h('p', null, d.treatment), 'warn', 'shield'),
      sec(t('x_prevention'), bullets(d.prevention), null, 'check'),
      sec(t('x_specialist'), bullets(d.specialists), null, 'steth'),
      sourcesBlock(d.sources, d.updated), disclaimerNote()
    ];
    return h('div.view', null, parts);
  }

  // ---------------- SYMPTOM ----------------
  function symptom(params, id) {
    const raw = DB.symptomById.get(id); if (!raw) return notFound();
    const s = DB.symptomView(raw, lang()); g.MG.cur = { kind: 'symptom', id };
    return h('div.view', null,
      header('symptom', s.name),
      h('div.disc', null, icon('info', 18), h('span', null, t('sg_intro'))),
      sec(t('sg_red'), h('p', null, s.red), 'red', 'alert'),
      sec(t('sg_see'), bullets(s.specialists), null, 'steth'),
      s.related.length ? h('section.stack', null, h('h3', null, t('sg_related')), s.related.map(r => itemCard('disease', r))) : null,
      disclaimerNote());
  }

  function notFound() { return h('div.view', null, h('div.empty', null, icon('box', 44), h('h3', null, t('not_found_page')), h('button.btn', { onclick: () => g.MG.go('/home') }, t('nav_home')))); }

  g.MG_VIEWS_REF = { home, search, drugsList, diseasesList, symptomsList, drug, disease, symptom, notFound, itemCard, favButton, disclaimerNote, addHistory, KIND_ICON, isFav };
})(window);
