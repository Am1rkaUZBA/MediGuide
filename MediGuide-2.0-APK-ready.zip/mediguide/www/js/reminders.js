/* Reminder engine. Two honest modes:
 *  - Native (Capacitor APK + @capacitor/local-notifications): real scheduled daily notifications, work with app closed.
 *  - Web fallback: checks the clock while the app is open and shows an in-app alert (+ Web Notification if allowed).
 * Reminders carry only a name, times and a note. The app never sets doses or schedules.
 */
(function (g) {
  'use strict';
  const ST = g.MG_STORE;

  function native() { const C = g.Capacitor; return C && C.isNativePlatform && C.isNativePlatform() && C.Plugins && C.Plugins.LocalNotifications ? C.Plugins.LocalNotifications : null; }
  const isNative = () => !!native();

  function hashId(s) { let x = 7; for (let i = 0; i < s.length; i++) x = (x * 31 + s.charCodeAt(i)) | 0; return Math.abs(x) % 2000000000 + 1; }
  const notifId = (rid, i) => (hashId(rid) + i) % 2147483000 + 1;

  async function permission(ask) {
    const N = native();
    try {
      if (N) { let p = await N.checkPermissions(); if (p.display !== 'granted' && ask) p = await N.requestPermissions(); return p.display; }
      if (typeof Notification === 'undefined') return 'unsupported';
      if (Notification.permission === 'default' && ask) return await Notification.requestPermission();
      return Notification.permission;
    } catch (e) { return 'denied'; }
  }

  async function cancel(r) {
    const N = native(); if (!N) return;
    try { await N.cancel({ notifications: r.times.map((_, i) => ({ id: notifId(r.id, i) })) }); } catch (e) { /* ignore */ }
  }
  async function schedule(r, titleFn) {
    const N = native(); if (!N || !r.on) return false;
    try {
      await cancel(r);
      await N.schedule({ notifications: r.times.map((tm, i) => {
        const [hh, mm] = tm.split(':').map(Number);
        return { id: notifId(r.id, i), title: 'MediGuide', body: titleFn(r.name), schedule: { on: { hour: hh, minute: mm }, allowWhileIdle: true } };
      }) });
      return true;
    } catch (e) { return false; }
  }
  async function syncAll(titleFn) { const list = ST.get('reminders'); for (const r of list) { if (r.on) await schedule(r, titleFn); else await cancel(r); } }

  let timer = null, lastKey = '';
  function startWebWatcher(onDue) {
    if (timer) clearInterval(timer);
    timer = setInterval(() => {
      if (isNative()) return;
      const d = new Date(); const hm = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
      const day = d.toDateString();
      ST.get('reminders').filter(r => r.on && r.times.includes(hm)).forEach(r => {
        const key = day + hm + r.id; if (lastKey.includes(key)) return; lastKey += '|' + key; if (lastKey.length > 2000) lastKey = lastKey.slice(-500);
        onDue(r);
      });
    }, 15000);
  }

  g.MG_REMINDERS = { isNative, permission, schedule, cancel, syncAll, startWebWatcher };
})(window);
