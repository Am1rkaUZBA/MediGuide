// End-to-end smoke test in headless Chromium (Playwright). Usage: node tests/e2e.js [shots-dir]
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.join(__dirname, '..', 'www');
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const shots = process.argv[2];
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('  ok  ' + m); } else { fail++; console.log('  FAIL ' + m); } };

(async () => {
  const srv = http.createServer((q, r) => { let p = decodeURIComponent(q.url.split('?')[0]); if (p === '/') p = '/index.html'; const f = path.join(ROOT, p); if (!f.startsWith(ROOT) || !fs.existsSync(f)) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' }); fs.createReadStream(f).pipe(r); }).listen(0);
  const base = 'http://127.0.0.1:' + srv.address().port + '/';
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 360, height: 760 }, deviceScaleFactor: 2, locale: 'ru-RU', isMobile: true, hasTouch: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', e => errors.push('PAGEERROR ' + e.message));
  const shot = async n => { await page.waitForTimeout(400); if (shots) { fs.mkdirSync(shots, { recursive: true }); await page.screenshot({ path: path.join(shots, n + '.png') }); } };
  const txt = () => page.locator('body').innerText();

  console.log('first run');
  await page.goto(base); await page.waitForSelector('.sheet');
  ok(/Прежде чем начать/.test(await txt()), 'welcome/disclaimer sheet shown in Russian');
  await shot('01-welcome');
  await page.click('.sheet .btn.block'); await page.waitForSelector('.sheet', { state: 'detached' });
  ok(await page.locator('.hero h1').count() === 1, 'home renders');
  await shot('02-home');

  console.log('search');
  await page.click('.bottomnav button >> nth=1');
  await page.waitForSelector('input[type=search]');
  await page.fill('input[type=search]', 'ибупрофин');
  await page.waitForSelector('.item');
  ok(/Ибупрофен/.test(await page.locator('.item').first().innerText()), 'typo "ибупрофин" finds Ибупрофен');
  await shot('03-search');
  await page.fill('input[type=search]', 'zzzqqq');
  await page.waitForSelector('.empty');
  ok(/Ничего не найдено/.test(await txt()), 'empty-state shown for no results');
  await page.fill('input[type=search]', '<img src=x onerror=window.__xss=1>');
  await page.waitForTimeout(300);
  ok(await page.evaluate(() => window.__xss === undefined), 'XSS payload in search does not execute');
  await page.fill('input[type=search]', 'headache');
  await page.waitForSelector('.item');
  ok(/Головная боль/.test(await page.locator('.item').first().innerText()), 'English query returns result localized to Russian');

  console.log('drug detail + favorites + history');
  await page.fill('input[type=search]', 'варфарин'); await page.waitForSelector('.item');
  await page.locator('.item .t', { hasText: 'Варфарин' }).first().click();
  await page.waitForSelector('h1');
  ok(/Варфарин/.test(await page.locator('h1').innerText()), 'drug page opens');
  ok(/Дозировки намеренно не указаны/.test(await txt()), 'drug page states doses are intentionally absent');
  ok(/Источники/.test(await txt()) && await page.locator('a[href^="https://"]').count() >= 3, 'sources with links present');
  ok(await page.locator('a[target=_blank][rel*=noopener]').count() >= 3, 'external links use noopener');
  await shot('04-drug');
  await page.locator('h1 ~ button, .row > button[aria-pressed]').first().click();
  ok(await page.evaluate(() => JSON.parse(localStorage.getItem('mg2_favs')).includes('drug:warfarin')), 'favorite persisted to storage');
  await page.reload(); await page.waitForSelector('h1');
  ok(await page.locator('button[aria-pressed="true"]').count() >= 1, 'favorite survives reload');

  console.log('language switch');
  await page.evaluate(() => { location.hash = '#/settings'; });
  await page.waitForSelector('.seg');
  await page.locator('.seg button', { hasText: "O'zbekcha" }).click();
  await page.waitForTimeout(150);
  ok(/Sozlamalar/.test(await txt()), 'switch to Uzbek changes the whole UI');
  await page.evaluate(() => { location.hash = '#/drug/warfarin'; }); await page.waitForSelector('h1');
  ok(/Varfarin/.test(await page.locator('h1').innerText()) && /Qarshi ko'rsatmalar/.test(await txt()), 'drug content is Uzbek');
  await shot('05-drug-uz');
  await page.evaluate(() => { location.hash = '#/settings'; }); await page.waitForSelector('.seg');
  await page.locator('.seg button', { hasText: 'English' }).click(); await page.waitForTimeout(150);
  ok(/Settings/.test(await txt()), 'switch to English');

  console.log('theme');
  await page.locator('.seg button', { hasText: 'Dark' }).click(); await page.waitForTimeout(150);
  ok(await page.evaluate(() => document.documentElement.getAttribute('data-theme')) === 'dark', 'dark theme applied');
  await shot('06-settings-dark');
  await page.locator('.seg button', { hasText: 'Light' }).click(); await page.waitForTimeout(100);
  await page.locator('.seg button', { hasText: 'Русский' }).click(); await page.waitForTimeout(100);

  console.log('interactions');
  await page.evaluate(() => { location.hash = '#/interactions'; }); await page.waitForSelector('input[type=search]');
  for (const q of ['warfarin', 'ibuprofen']) { await page.fill('input[type=search]', q); await page.locator('.item').first().click(); }
  await page.waitForSelector('.card.red');
  ok(/кровотечен/i.test(await txt()), 'warfarin + ibuprofen shows documented bleeding risk');
  await shot('07-interactions');

  console.log('emergency, symptoms, disease');
  await page.evaluate(() => { location.hash = '#/emergency'; }); await page.waitForSelector('.num-link');
  ok(await page.locator('details').count() === 12, 'emergency guide lists 12 scenarios');
  await page.locator('summary').first().click();
  ok(/Немедленно вызовите скорую/.test(await txt()), 'emergency steps open and start with calling EMS');
  await shot('08-emergency');
  await page.evaluate(() => { location.hash = '#/disease/influenza'; }); await page.waitForSelector('h1');
  ok(/Когда нужна срочная помощь/.test(await txt()) && /МКБ-10/.test(await txt()), 'disease page has red flags + ICD');
  await shot('09-disease');
  await page.evaluate(() => { location.hash = '#/symptom/headache'; }); await page.waitForSelector('h1');
  ok(/Срочно, если/.test(await txt()) && /не ставит диагноз/.test(await txt()), 'symptom page shows red flags and no-diagnosis note');

  console.log('journal + reminders + clear');
  await page.evaluate(() => { location.hash = '#/journal'; }); await page.waitForSelector('textarea');
  await page.fill('textarea', '<b onmouseover=window.__x=1>тест</b>'); await page.locator('.mood button').nth(3).click();
  await page.locator('.btn.block', { hasText: 'Сохранить' }).click(); await page.waitForTimeout(150);
  ok(await page.locator('b').count() === 0 && /<b onmouseover/.test(await txt()), 'journal text rendered as plain text (no HTML injection)');
  await shot('10-journal');
  await page.evaluate(() => { location.hash = '#/reminders'; }); await page.waitForSelector('.btn.block');
  await page.locator('.btn.block', { hasText: 'Добавить' }).click(); await page.waitForSelector('.sheet');
  await page.fill('.sheet input[maxlength="80"]', 'Тестовое'); await page.locator('.sheet .btn', { hasText: 'Сохранить' }).click();
  await page.waitForSelector('.switch');
  ok(await page.evaluate(() => JSON.parse(localStorage.getItem('mg2_reminders')).length) === 1, 'reminder saved');
  await shot('11-reminders');
  await page.evaluate(() => { location.hash = '#/settings'; }); await page.waitForSelector('.seg');
  await page.locator('.btn.danger', { hasText: 'Удалить все' }).click(); await page.locator('.sheet .btn.danger').click(); await page.waitForTimeout(300);
  ok(await page.evaluate(() => ['favs', 'journal', 'reminders', 'history'].every(k => localStorage.getItem('mg2_' + k) === null)), '"Delete all my data" wipes storage');

  console.log('offline');
  await ctx.setOffline(true);
  await page.evaluate(() => { location.hash = '#/home'; }); await page.waitForTimeout(200);
  ok(/Нет интернета/.test(await txt()), 'offline banner shown');
  ok(await page.locator('.hero').count() === 1, 'app still renders offline');
  await ctx.setOffline(false);

  console.log('layout');
  let overflowSeen = 0;
  for (const w of [320, 360, 412]) {
    await page.setViewportSize({ width: w, height: 740 });
    for (const hsh of ['#/home', '#/drug/amoxiclav', '#/settings', '#/emergency']) {
      await page.evaluate(h => { location.hash = h; }, hsh); await page.waitForTimeout(120);
      const over = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1 || document.getElementById('main').scrollWidth > document.getElementById('main').clientWidth + 1);
      if (over) { overflowSeen++; ok(false, `horizontal overflow at ${w}px on ${hsh}`); }
    }
  }
  ok(overflowSeen === 0, 'no horizontal overflow at 320/360/412px (home, drug, settings, emergency)');

  ok(errors.length === 0, 'no console/page errors' + (errors.length ? ': ' + errors.join(' | ') : ''));
  console.log(`\n${pass} passed, ${fail} failed`);
  await browser.close(); srv.close(); process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
