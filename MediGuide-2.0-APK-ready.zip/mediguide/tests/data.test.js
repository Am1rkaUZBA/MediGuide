// Data integrity + i18n completeness + search quality. Run: node tests/data.test.js
const assert = require('assert');
const DB = require('../www/js/db.js');
const I18N = require('../www/js/i18n.js');
const S = require('../www/js/search.js');
const T = DB.termKeys;
let pass = 0, fail = 0;
const test = (name, fn) => { try { fn(); pass++; console.log('  ok  ' + name); } catch (e) { fail++; console.log('  FAIL ' + name + '\n       ' + e.message); } };
const L = ['ru', 'en', 'uz'];
const nonEmpty = s => typeof s === 'string' && s.trim().length > 1;

test('UI strings: every key has non-empty ru/en/uz', () => {
  const bad = []; for (const [k, v] of Object.entries(I18N.S)) for (const l of L) if (!nonEmpty(v[l])) bad.push(k + '.' + l);
  assert.deepStrictEqual(bad, []);
});
test('UI strings: placeholders match across languages', () => {
  const bad = []; for (const [k, v] of Object.entries(I18N.S)) { const ph = l => (v[l].match(/\{\w+\}/g) || []).sort().join(','); if (ph('ru') !== ph('en') || ph('en') !== ph('uz')) bad.push(k); }
  assert.deepStrictEqual(bad, []);
});
test('medical terms: every term has non-empty ru/en/uz', () => {
  const bad = []; for (const [k, v] of Object.entries(T)) for (const l of L) if (!nonEmpty(v[l])) bad.push(k + '.' + l);
  assert.deepStrictEqual(bad, []);
});
test('no placeholder / lorem / TODO text anywhere in data', () => {
  const blob = JSON.stringify([T, DB.drugs, DB.diseases, DB.symptoms]);
  assert.ok(!/lorem|TODO|TBD|placeholder/i.test(blob));
  // the original project invented drugs by appending suffixes like 'Forte'/'Plus' — forbid those as whole-word drug-name suffixes
  for (const d of DB.drugs) for (const n of [d.ru, d.inn, d.uz]) assert.ok(!/\b(Форте|Плюс|Ультра|Экспресс|Ретард|Нео|Лонг|Био|Макс|Про|Forte|Plus|Ultra|Express|Retard|Neo|Long|Bio|Max|Pro)\b/.test(n), 'suffix-style name: ' + n);
});
test('drugs: unique ids, INN, ATC format, rx flag, all term refs resolve, lists non-empty', () => {
  const ids = new Set();
  for (const d of DB.drugs) {
    assert.ok(!ids.has(d.id), 'dup ' + d.id); ids.add(d.id);
    assert.ok(nonEmpty(d.inn) && nonEmpty(d.ru) && nonEmpty(d.uz), d.id + ' names');
    assert.ok(/^[A-Z]\d{2}[A-Z]{1,2}\d{0,2}( \/ [A-Z]\d{2}[A-Z]{2}\d{2})?$/.test(d.atc), d.id + ' ATC ' + d.atc);
    assert.ok(['otc', 'rx', 'varies'].includes(d.rx), d.id + ' rx');
    for (const k of ['forms', 'ind', 'ci', 'se', 'w']) { assert.ok(d[k].length > 0, d.id + ' empty ' + k); d[k].forEach(x => assert.ok(T[x], d.id + ' term ' + x)); }
    assert.ok(T[d.cat], d.id + ' cat');
  }
});
test('drugs: NO dosing numbers in any rendered drug text', () => {
  for (const d of DB.drugs) for (const l of L) { const v = DB.drugView(d, l); const txt = [v.indications, v.contraindications, v.sideEffects, v.warnings, v.forms].flat().join(' ');
    const m = txt.match(/\b\d+\s?(mg|мг|g\b|мкг|mcg|ml|мл|ме\b|IU)/i);
    assert.ok(!m, d.id + ' ' + l + ' has dose-like text: ' + (m && m[0])); }
});
test('diseases: required sections present with equal list lengths in ru/en/uz', () => {
  const lists = ['causes', 'symptoms', 'complications', 'risk', 'diagnosis', 'prevention', 'urgent'];
  for (const d of DB.diseases) {
    assert.ok(d.title.length === 3 && d.title.every(nonEmpty), d.id + ' title');
    assert.ok(d.desc.length === 3 && d.desc.every(nonEmpty), d.id + ' desc');
    assert.ok(d.treatment.length === 3 && d.treatment.every(nonEmpty), d.id + ' treatment');
    assert.ok(d.transmission.length === 3, d.id + ' transmission shape');
    assert.ok(d.transmission.every(x => x === null) || d.transmission.every(nonEmpty), d.id + ' transmission mixed null');
    for (const k of lists) { assert.strictEqual(d[k].length, 3, d.id + ' ' + k + ' langs'); assert.ok(d[k][0].length > 0, d.id + ' ' + k + ' empty'); assert.ok(d[k][0].length === d[k][1].length && d[k][1].length === d[k][2].length, `${d.id}.${k} length mismatch ${d[k].map(a => a.length)}`); d[k].flat().forEach(x => assert.ok(nonEmpty(x), d.id + ' ' + k + ' blank')); }
    assert.ok(d.urgent[0].length >= 2, d.id + ' needs red-flag list');
    assert.ok(/^[A-Z]\d{2}/.test(d.icd), d.id + ' icd');
    assert.ok(d.src.length >= 1);
  }
});
test('diseases: every one links to resolvable sources', () => {
  for (const d of DB.diseases) for (const k of d.src) assert.ok(DB.sources.resolve(k), d.id + ' src ' + k);
});
test('sources: all URLs are https and from known official domains', () => {
  const ok = /^https:\/\/(www\.who\.int|atcddd\.fhi\.no|medlineplus\.gov|dailymed\.nlm\.nih\.gov|www\.fda\.gov|www\.cdc\.gov|www\.ema\.europa\.eu)\//;
  for (const s of Object.values(DB.sources.SRC)) assert.ok(ok.test(s.url), s.url);
});
test('symptoms: ru/en/uz names + red flags + specialists', () => {
  for (const s of DB.symptoms) { assert.ok(s.name.length === 3 && s.name.every(nonEmpty), s.id); assert.ok(s.red.length === 3 && s.red.every(nonEmpty), s.id + ' red'); assert.ok(s.spec.length && s.spec.every(k => T[k]), s.id + ' spec'); }
});
test('emergency: 12 scenarios, EMS-first, equal list lengths across languages', () => {
  assert.strictEqual(DB.emergency.E.length, 12);
  for (const e of DB.emergency.E) {
    assert.ok(e.title.length === 3 && e.title.every(nonEmpty), e.id);
    for (const k of ['signs', 'actions']) { assert.ok(e[k][0].length === e[k][1].length && e[k][1].length === e[k][2].length, e.id + ' ' + k + ' mismatch'); e[k].flat().forEach(x => assert.ok(nonEmpty(x))); }
    if (e.level === 'critical') assert.ok(/скор|emergency|tez yordam/i.test(e.actions[0][0] + e.actions[1][0] + e.actions[2][0]), e.id + ' critical must mention calling EMS first');
  }
});
test('interactions: symmetric lookup, valid effect keys, texts in 3 languages', () => {
  const E = require('../www/js/data/interactions.js').EFFECTS;
  for (const [k, v] of Object.entries(E)) { assert.ok(v.t.length === 3 && v.t.every(nonEmpty), k); assert.ok(['major', 'moderate'].includes(v.sev), k); }
  const a = DB.checkInteractions(['warfarin', 'ibuprofen']), b = DB.checkInteractions(['ibuprofen', 'warfarin']);
  assert.strictEqual(a.length, 1); assert.strictEqual(b.length, 1); assert.deepStrictEqual(a[0].effects, b[0].effects);
  assert.deepStrictEqual(DB.checkInteractions(['paracetamol', 'loratadine']), [], 'unlisted pair must be empty (and UI says "not a guarantee")');
  assert.deepStrictEqual(DB.checkInteractions(['warfarin', 'warfarin']), [], 'same drug twice');
});
test('search: typos, translit, brands, cross-language, ATC, empty/garbage', () => {
  const top = q => { const r = DB.find(q, { limit: 1 })[0]; return r && r.item.id; };
  const cases = { 'ибупрофин': 'ibuprofen', 'ibuprufen': 'ibuprofen', 'нурофен': 'ibuprofen', 'парацетомол': 'paracetamol', 'paratsetamol': 'paracetamol', 'метфармин': 'metformin', 'amoxicilin': 'amoxicillin', 'gripp': 'influenza', 'грип': 'influenza', 'asthma': 'asthma', 'астма': 'asthma', 'migren': 'migraine', 'мигрень': 'migraine', 'головная боль': 'headache', 'bosh ogrigi': 'headache', 'изжога': 'heartburn', 'B01AA03': 'warfarin', 'варфарин': 'warfarin' };
  for (const [q, id] of Object.entries(cases)) assert.strictEqual(top(q), id, `"${q}" → ${top(q)} (want ${id})`);
  assert.strictEqual(DB.find('').length, 0); assert.strictEqual(DB.find('   ').length, 0); assert.strictEqual(DB.find('zzzqqq').length, 0);
  assert.doesNotThrow(() => DB.find('<script>alert(1)</script> ' + 'x'.repeat(5000)));
  assert.strictEqual(DB.find('M01AE01', { limit: 5 }).filter(r => r.item.id === 'naproxen').length, 0, 'ATC codes are not fuzzy-matched');
});
test('search: type filter works', () => {
  assert.ok(DB.find('диабет', { type: 'disease' }).every(r => r.item.kind === 'disease'));
  assert.ok(DB.find('диабет', { type: 'drug' }).every(r => r.item.kind === 'drug'));
});
test('search: distance() sanity', () => { assert.strictEqual(S.distance('abc', 'acb', 2), 1); assert.strictEqual(S.distance('kitten', 'sitting', 5), 3); assert.ok(S.distance('abc', 'xyz', 1) > 1); });
test('views localize for every record in every language without throwing', () => {
  for (const l of L) { for (const d of DB.drugs) DB.drugView(d, l); for (const d of DB.diseases) DB.diseaseView(d, l); for (const s of DB.symptoms) DB.symptomView(s, l); }
});
test('every disease symptom id and every symptom specialists resolve; every symptom is used or standalone-valid', () => {
  for (const d of DB.diseases) d.sym.forEach(s => assert.ok(DB.symptomById.has(s), d.id + ' → ' + s));
});

console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
