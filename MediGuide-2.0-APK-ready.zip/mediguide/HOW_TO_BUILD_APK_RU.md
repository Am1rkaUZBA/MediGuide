# Как получить APK MediGuide 2.0 бесплатно

В проекте уже есть GitHub Actions workflow для сборки устанавливаемого DEBUG APK. Исправлена настройка npm cache: в исходном архиве не было package-lock.json, из-за чего настройка cache могла остановить workflow до установки зависимостей.

## Шаги

1. Создай аккаунт на https://github.com, если его ещё нет.
2. Создай новый репозиторий (например, `MediGuide`), можно выбрать Private.
3. Распакуй этот ZIP. Загружать нужно **содержимое папки `mediguide`**, а не сам ZIP и не внешнюю папку `mediguide` как один файл. В корне репозитория должны лежать `package.json`, `capacitor.config.json`, папки `www`, `resources`, `tests` и `.github`.
4. Добавь файлы проекта в репозиторий и отправь commit в ветку `main`. После push сборка запустится автоматически.
5. На странице репозитория открой **Actions** → workflow **Build Android APK (debug)**. Дождись зелёной галочки.
6. Открой завершённый запуск workflow, пролистай вниз до **Artifacts** и скачай `mediguide-debug-apk`. Это ZIP-архив с файлом `app-debug.apk` внутри.
7. Распакуй скачанный artifact и установи `app-debug.apk` на Android. Если Android спросит, разреши установку из этого источника.

Если автоматическая сборка не запустилась: открой вкладку **Actions**, разреши GitHub Actions для репозитория, выбери **Build Android APK (debug)** и нажми **Run workflow**.

## Важно

- Этот workflow создаёт DEBUG APK для тестирования и установки на своё устройство.
- Для публикации в Google Play обычно нужен подписанный релизный Android App Bundle (`.aab`), а не этот debug APK.
- Сам APK ещё не включён в этот ZIP: его создаёт GitHub Actions после загрузки исходников.
