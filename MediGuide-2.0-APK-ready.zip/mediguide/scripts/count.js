const d = '/home/claude/mediguide/www/js/data/';
const T = require(d + 'terms-med.js');
const drugs = [...require(d + 'drugs-1.js'), ...require(d + 'drugs-2.js')];
const dis = [...require(d + 'diseases-1.js'), ...require(d + 'diseases-2.js')];
const sym = require(d + 'symptoms.js');
const I = require(d + 'interactions.js');
const E = require('/home/claude/mediguide/www/js/data/emergency.js');
const S = require(d + 'sources.js');
console.log({ drugs: drugs.length, diseases: dis.length, symptoms: sym.length, pairs: I.expand().length, emergency: E.E.length });
const errs = [];
const ids = new Set(drugs.map(x => x.id));
if (ids.size !== drugs.length) errs.push('dup drug id');
const symIds = new Set(sym.map(s => s.id));
for (const x of drugs) for (const k of ['cat','forms','ind','ci','se','w']) for (const t of [].concat(x[k])) if (!T[t]) errs.push(`drug ${x.id}: missing term ${t}`);
for (const x of dis) {
  if (!T[x.cat]) errs.push(`dis ${x.id}: cat ${x.cat}`);
  for (const t of x.spec) if (!T[t]) errs.push(`dis ${x.id}: spec ${t}`);
  for (const s of x.sym) if (!symIds.has(s)) errs.push(`dis ${x.id}: unknown symptom ${s}`);
  for (const s of x.src) if (!S.resolve(s)) errs.push(`dis ${x.id}: src ${s}`);
}
for (const s of sym) for (const t of s.spec) if (!T[t]) errs.push(`sym ${s.id}: spec ${t}`);
for (const p of I.expand()) { if (!ids.has(p.a)) errs.push('ix unknown ' + p.a); if (!ids.has(p.b)) errs.push('ix unknown ' + p.b); }
console.log(errs.length ? errs : 'refs OK');
